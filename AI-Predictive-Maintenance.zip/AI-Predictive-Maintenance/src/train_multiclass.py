"""
train_multiclass.py
-------------------
TASK 2 — Failure Type Classification (5-class, failure rows only)

Trains and evaluates three models:
  1. Logistic Regression  (class_weight="balanced")
  2. Random Forest        (class_weight="balanced")
  3. XGBoost              (sample_weight computed from class frequencies)

Evaluation metrics (per model):
  Accuracy, Macro Precision, Macro Recall, Macro F1, Weighted F1,
  Confusion Matrix, Per-class Classification Report

Best model selected by Macro F1.
Feature importances saved for the best tree-based model.

Note: "Random Failures" has only 14 training samples.
Per-class recall for this class is reported separately and may be low.
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import joblib
warnings.filterwarnings("ignore")

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report,
)
import xgboost as xgb

sys.path.insert(0, os.path.dirname(__file__))

PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
DATA_DIR     = os.path.join(PROJECT_ROOT, "data")
MODELS_DIR   = os.path.join(PROJECT_ROOT, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

RESULTS_PATH = os.path.join(MODELS_DIR, "multi_results.json")

# -------------------------------------------------------------
# 1. LOAD PREPROCESSED DATA
# -------------------------------------------------------------
X_train = np.load(os.path.join(DATA_DIR, "multi_X_train.npy"))
X_test  = np.load(os.path.join(DATA_DIR, "multi_X_test.npy"))
y_train = np.load(os.path.join(DATA_DIR, "multi_y_train.npy"))
y_test  = np.load(os.path.join(DATA_DIR, "multi_y_test.npy"))

with open(os.path.join(MODELS_DIR, "multi_feature_names.json")) as f:
    feature_names = json.load(f)

with open(os.path.join(MODELS_DIR, "multi_label_encoder_le.json")) as f:
    le_data = json.load(f)
class_names = le_data["classes"]   # ['Heat Dissipation Failure', ...]
n_classes   = len(class_names)

# Compute per-class sample weights for XGBoost (mirrors class_weight="balanced")
class_counts   = np.bincount(y_train.astype(int))
total_samples  = len(y_train)
class_weights  = total_samples / (n_classes * class_counts)
sample_weights = np.array([class_weights[c] for c in y_train.astype(int)])

print("=" * 65)
print("  TASK 2 -- Failure Type Classification: Model Training")
print("=" * 65)
print(f"\n  Training set : {X_train.shape[0]} rows, {X_train.shape[1]} features")
print(f"  Test set     : {X_test.shape[0]} rows")
print(f"  Classes ({n_classes}): {class_names}")
print(f"\n  Per-class training counts:")
for i, (name, cnt) in enumerate(zip(class_names, class_counts)):
    print(f"    {i} {name:<30}: {cnt:>3} samples  (weight={class_weights[i]:.3f})")

# -------------------------------------------------------------
# 2. MODEL DEFINITIONS
# -------------------------------------------------------------
models = {
    "Logistic Regression": LogisticRegression(
        class_weight="balanced",
        max_iter=2000,
        random_state=42,
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=300,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    ),
    "XGBoost": xgb.XGBClassifier(
        n_estimators=300,
        num_class=n_classes,
        objective="multi:softprob",
        eval_metric="mlogloss",
        random_state=42,
        verbosity=0,
    ),
}

# -------------------------------------------------------------
# 3. TRAIN + EVALUATE
# -------------------------------------------------------------
results = {}

def evaluate(name, model, X_tr, y_tr, X_te, y_te, sw=None):
    if sw is not None:
        model.fit(X_tr, y_tr, sample_weight=sw)
    else:
        model.fit(X_tr, y_tr)

    y_pred = model.predict(X_te)

    acc     = accuracy_score(y_te, y_pred)
    mac_p   = precision_score(y_te, y_pred, average="macro",    zero_division=0)
    mac_r   = recall_score   (y_te, y_pred, average="macro",    zero_division=0)
    mac_f1  = f1_score       (y_te, y_pred, average="macro",    zero_division=0)
    wgt_f1  = f1_score       (y_te, y_pred, average="weighted", zero_division=0)
    cm      = confusion_matrix(y_te, y_pred).tolist()
    cr      = classification_report(y_te, y_pred,
                                    target_names=class_names,
                                    zero_division=0)

    # Per-class F1 for detailed tracking
    per_class_f1 = f1_score(y_te, y_pred, average=None, zero_division=0).tolist()
    per_class_f1_dict = {class_names[i]: round(per_class_f1[i], 4)
                         for i in range(len(class_names))}

    print(f"\n{'-'*65}")
    print(f"  Model: {name}")
    print(f"{'-'*65}")
    print(f"  Accuracy       : {acc:.4f}")
    print(f"  Macro Precision: {mac_p:.4f}")
    print(f"  Macro Recall   : {mac_r:.4f}")
    print(f"  Macro F1       : {mac_f1:.4f}   <-- primary metric")
    print(f"  Weighted F1    : {wgt_f1:.4f}")
    print(f"\n  Per-class F1:")
    for cls, val in per_class_f1_dict.items():
        flag = "  *** LOW ***" if val < 0.30 else ""
        print(f"    {cls:<30}: {val:.4f}{flag}")
    print(f"\n  Confusion Matrix (rows=actual, cols=predicted):")
    header_row = "    " + "".join(f"  C{i}" for i in range(n_classes))
    print(header_row)
    for i, row in enumerate(cm):
        row_str = "  ".join(f"{v:3}" for v in row)
        print(f"    C{i} | {row_str}")
    print(f"\n  Classification Report:")
    for line in cr.strip().split("\n"):
        print(f"    {line}")

    return {
        "accuracy":         round(acc,    4),
        "macro_precision":  round(mac_p,  4),
        "macro_recall":     round(mac_r,  4),
        "macro_f1":         round(mac_f1, 4),
        "weighted_f1":      round(wgt_f1, 4),
        "per_class_f1":     per_class_f1_dict,
        "confusion_matrix": cm,
        "classification_report": cr,
    }

for name, model in models.items():
    sw = sample_weights if name == "XGBoost" else None
    results[name] = evaluate(name, model, X_train, y_train, X_test, y_test, sw=sw)
    joblib.dump(model, os.path.join(MODELS_DIR,
                f"multi_{name.lower().replace(' ', '_')}.joblib"))

# -------------------------------------------------------------
# 4. MODEL COMPARISON TABLE
# -------------------------------------------------------------
print(f"\n{'='*65}")
print(f"  MULTICLASS MODEL COMPARISON")
print(f"{'='*65}")
header = (f"  {'Model':<25} {'Acc':>6} {'MacP':>6} "
          f"{'MacR':>6} {'MacF1':>7} {'WgtF1':>7}")
print(header)
print(f"  {'-'*60}")
for name, r in results.items():
    print(f"  {name:<25} {r['accuracy']:>6.4f} {r['macro_precision']:>6.4f} "
          f"{r['macro_recall']:>6.4f} {r['macro_f1']:>7.4f} "
          f"{r['weighted_f1']:>7.4f}")

# -------------------------------------------------------------
# 5. BEST MODEL SELECTION  (by Macro F1)
# -------------------------------------------------------------
best_name = max(results, key=lambda n: results[n]["macro_f1"])
print(f"\n  Best model (by Macro F1): {best_name}")
r = results[best_name]
print(f"    Macro F1       : {r['macro_f1']}")
print(f"    Macro Recall   : {r['macro_recall']}")
print(f"    Weighted F1    : {r['weighted_f1']}")

# -------------------------------------------------------------
# 6. MINORITY CLASS SPOTLIGHT
# -------------------------------------------------------------
print(f"\n  Minority class spotlight — 'Random Failures' F1 per model:")
for name, r in results.items():
    rf_f1 = r["per_class_f1"].get("Random Failures", "N/A")
    print(f"    {name:<25}: {rf_f1}")

# -------------------------------------------------------------
# 7. FEATURE IMPORTANCE (best tree-based model)
# -------------------------------------------------------------
tree_models = {n: m for n, m in models.items()
               if n in ("Random Forest", "XGBoost")}
best_tree_name = max(tree_models,
                     key=lambda n: results[n]["macro_f1"])
best_tree = tree_models[best_tree_name]

if hasattr(best_tree, "feature_importances_"):
    importances = best_tree.feature_importances_
    imp_df = pd.DataFrame({
        "feature": feature_names,
        "importance": importances,
    }).sort_values("importance", ascending=False).reset_index(drop=True)

    print(f"\n  Feature Importances ({best_tree_name}):")
    print(f"  {'Feature':<35} {'Importance':>10}")
    print(f"  {'-'*47}")
    for _, row in imp_df.iterrows():
        bar = "#" * int(row["importance"] * 40)
        print(f"  {row['feature']:<35} {row['importance']:>10.4f}  {bar}")

    imp_df.to_csv(os.path.join(MODELS_DIR,
                  "multi_feature_importance.csv"), index=False)
    print(f"\n  Saved: models/multi_feature_importance.csv")

# -------------------------------------------------------------
# 8. SAVE RESULTS
# -------------------------------------------------------------
summary = {
    "task": "multiclass_classification",
    "best_model": best_name,
    "models": results,
}
with open(RESULTS_PATH, "w") as f:
    json.dump(summary, f, indent=2)
print(f"\n  Saved: models/multi_results.json")

print(f"\n{'='*65}")
print(f"  Multiclass model training COMPLETE.")
print(f"{'='*65}")
