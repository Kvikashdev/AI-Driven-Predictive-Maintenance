"""
data_inspection.py
------------------
Complete dataset analysis for the AI-Driven Predictive Maintenance project.
Does NOT train any models — pure exploration and quality audit only.
"""

import pandas as pd
import numpy as np
import os

CSV_PATH = os.path.join(os.path.dirname(__file__), "..", "data", "predictive_maintenance.csv")

# ─────────────────────────────────────────────
# 1. LOAD
# ─────────────────────────────────────────────
df = pd.read_csv(CSV_PATH)

print("=" * 65)
print("  AI-Driven Predictive Maintenance — Dataset Inspection")
print("=" * 65)

# ─────────────────────────────────────────────
# 2. SHAPE & COLUMNS
# ─────────────────────────────────────────────
print(f"\n[1] Shape: {df.shape[0]} rows × {df.shape[1]} columns\n")
print("[2] Column names:")
for col in df.columns:
    print(f"    • {col}")

# ─────────────────────────────────────────────
# 3. DATA TYPES
# ─────────────────────────────────────────────
print("\n[3] Data types:")
print(df.dtypes.to_string())

# ─────────────────────────────────────────────
# 4. MISSING VALUES
# ─────────────────────────────────────────────
missing = df.isnull().sum()
print("\n[4] Missing values per column:")
print(missing[missing >= 0].to_string())
total_missing = missing.sum()
print(f"    Total missing cells : {total_missing}")

# ─────────────────────────────────────────────
# 5. DUPLICATE ROWS
# ─────────────────────────────────────────────
dup_count = df.duplicated().sum()
print(f"\n[5] Duplicate rows : {dup_count}")

# ─────────────────────────────────────────────
# 6. DESCRIPTIVE STATISTICS
# ─────────────────────────────────────────────
print("\n[6] Descriptive statistics (numerical columns):")
print(df.describe().to_string())

# ─────────────────────────────────────────────
# 7. FEATURE CLASSIFICATION
# ─────────────────────────────────────────────
identifier_cols  = [c for c in df.columns if c in ("UDI", "Product ID")]
binary_target    = [c for c in df.columns if c == "Target"]
failure_type_col = [c for c in df.columns if c.lower() in ("failure type", "failuretype")]
categorical_cols = [c for c in df.select_dtypes(include=["object", "string"]).columns
                    if c not in identifier_cols + binary_target + failure_type_col]
numerical_cols   = list(df.select_dtypes(include=[np.number]).columns)
numerical_feats  = [c for c in numerical_cols
                    if c not in identifier_cols + binary_target + failure_type_col]

print(f"\n[7] Feature classification:")
print(f"    Identifier columns  : {identifier_cols}")
print(f"    Binary target       : {binary_target}")
print(f"    Failure type column : {failure_type_col}")
print(f"    Categorical features: {categorical_cols}")
print(f"    Numerical features  : {numerical_feats}")

# ─────────────────────────────────────────────
# 8. UNIQUE VALUES FOR CATEGORICAL COLUMNS
# ─────────────────────────────────────────────
all_cat = categorical_cols + failure_type_col
print("\n[8] Unique values for categorical columns:")
for col in all_cat:
    if col in df.columns:
        vals = df[col].value_counts().to_dict()
        print(f"    {col}: {vals}")

# ─────────────────────────────────────────────
# 9. TARGET DISTRIBUTION & CLASS IMBALANCE
# ─────────────────────────────────────────────
if binary_target and binary_target[0] in df.columns:
    tc = binary_target[0]
    vc = df[tc].value_counts()
    pct = df[tc].value_counts(normalize=True) * 100
    print(f"\n[9] Target distribution ('{tc}'):")
    for label in vc.index:
        print(f"    Class {label}: {vc[label]:>6}  ({pct[label]:.2f}%)")
    ratio = vc.max() / max(vc.min(), 1)
    print(f"    Imbalance ratio (majority/minority): {ratio:.2f}:1")
    if ratio > 10:
        print("    [!] SEVERE class imbalance detected (ratio > 10:1).")
    elif ratio > 3:
        print("    [!] Moderate class imbalance detected (ratio > 3:1).")
    else:
        print("    [OK] Classes are roughly balanced.")

# ─────────────────────────────────────────────
# 10. FAILURE TYPE DISTRIBUTION
# ─────────────────────────────────────────────
if failure_type_col and failure_type_col[0] in df.columns:
    fc = failure_type_col[0]
    fvc = df[fc].value_counts()
    print(f"\n[10] Failure Type distribution ('{fc}'):")
    for label, cnt in fvc.items():
        pct_val = cnt / len(df) * 100
        print(f"     {label:<30}: {cnt:>6}  ({pct_val:.2f}%)")

# ─────────────────────────────────────────────
# 11. DATA LEAKAGE CHECK
# ─────────────────────────────────────────────
print("\n[11] Data leakage check:")
if binary_target and failure_type_col:
    tc = binary_target[0]
    fc = failure_type_col[0]
    if tc in df.columns and fc in df.columns:
        # If Failure Type is not "No Failure" whenever Target == 1 -> leakage risk
        target_1 = df[df[tc] == 1][fc].value_counts()
        target_0 = df[df[tc] == 0][fc].value_counts()
        print(f"    Failure Type values when Target=1: {target_1.to_dict()}")
        print(f"    Failure Type values when Target=0: {target_0.to_dict()}")
        no_fail_in_target1 = (df[tc] == 1) & (df[fc].str.lower() == "no failure")
        if no_fail_in_target1.sum() == 0:
            print("    [!] 'Failure Type' column perfectly encodes the Target --"
                  " it is a LEAKY feature and must be EXCLUDED from ML features.")
        else:
            print("    [OK] 'Failure Type' does not perfectly predict Target.")
print("\n" + "=" * 65)
print("  Inspection complete. No models were trained.")
print("=" * 65)
