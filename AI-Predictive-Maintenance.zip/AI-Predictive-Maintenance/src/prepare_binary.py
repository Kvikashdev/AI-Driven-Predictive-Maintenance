"""
prepare_binary.py
-----------------
Data preparation for TASK 1: Binary Failure Prediction (Target = 0 / 1).

Steps performed:
  1. Load raw dataset
  2. Drop identifier columns (UDI, Product ID)
  3. Drop Failure Type  (Task 2 label — leakage if used as input)
  4. Select 5 numerical + 1 categorical feature
  5. 80/20 stratified train/test split (random_state=42)
  6. Fit scaler & OHE on X_train ONLY, transform both splits
  7. Document class distribution and imbalance ratio
  8. Save processed arrays + transformer params to data/ and models/

No model is trained here.
"""

import os
import sys
import numpy as np
import pandas as pd
import json

sys.path.insert(0, os.path.dirname(__file__))
from preprocessing import (
    load_raw, stratified_split,
    NumpyStandardScaler, NumpyOneHotEncoder,
    INPUT_FEATURES, NUMERICAL_FEATURES, CATEGORICAL_FEATURES,
    BINARY_TARGET, MULTICLASS_TARGET,
)

PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
DATA_OUT     = os.path.join(PROJECT_ROOT, "data")
MODELS_OUT   = os.path.join(PROJECT_ROOT, "models")
os.makedirs(DATA_OUT,   exist_ok=True)
os.makedirs(MODELS_OUT, exist_ok=True)

RANDOM_STATE = 42
TEST_SIZE    = 0.20

# ─────────────────────────────────────────────────────────────
print("=" * 65)
print("  TASK 1 -- Binary Failure Prediction: Data Preparation")
print("=" * 65)

# ─────────────────────────────────────────────────────────────
# 1. LOAD
# ─────────────────────────────────────────────────────────────
df = load_raw()
print(f"\n[1] Loaded dataset: {df.shape[0]} rows x {df.shape[1]} columns")

# ─────────────────────────────────────────────────────────────
# 2. FEATURE / TARGET SELECTION
# ─────────────────────────────────────────────────────────────
X = df[INPUT_FEATURES].copy()
y = df[BINARY_TARGET].copy()

print(f"\n[2] Features selected ({len(INPUT_FEATURES)}):")
for f in INPUT_FEATURES:
    print(f"    + {f}")
print(f"\n    Columns removed:")
print(f"    - UDI          (identifier -- no predictive value)")
print(f"    - Product ID   (identifier -- no predictive value)")
print(f"    - Failure Type (multiclass label -- data leakage if used as input)")

# ─────────────────────────────────────────────────────────────
# 3. TRAIN / TEST SPLIT  (stratified on Target)
# ─────────────────────────────────────────────────────────────
X_train, X_test, y_train, y_test = stratified_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
)

print(f"\n[3] Train/test split (80/20, stratified on Target):")
print(f"    Training set : {len(X_train)} rows")
print(f"    Test set     : {len(X_test)} rows")

# ─────────────────────────────────────────────────────────────
# 4. CLASS DISTRIBUTION
# ─────────────────────────────────────────────────────────────
def class_report(y_series, split_name):
    vc  = y_series.value_counts().sort_index()
    pct = y_series.value_counts(normalize=True).sort_index() * 100
    print(f"\n[4] Class distribution -- {split_name}:")
    for cls in vc.index:
        label = "No Failure" if cls == 0 else "Failure"
        print(f"    Class {cls} ({label}): {vc[cls]:>5}  ({pct[cls]:.2f}%)")
    ratio = vc.max() / max(vc.min(), 1)
    print(f"    Imbalance ratio: {ratio:.2f}:1")

class_report(y_train, "Training set")
class_report(y_test,  "Test set")

# ─────────────────────────────────────────────────────────────
# 5. PREPROCESSING  (fit ONLY on training data)
# ─────────────────────────────────────────────────────────────

# 5a. Extract numpy arrays for numerical columns
X_train_num = X_train[NUMERICAL_FEATURES].values.astype(float)
X_test_num  = X_test[NUMERICAL_FEATURES].values.astype(float)

# 5b. Scale numerical features
scaler = NumpyStandardScaler()
X_train_num_sc = scaler.fit_transform(X_train_num)   # fit on train only
X_test_num_sc  = scaler.transform(X_test_num)         # apply train params to test

# 5c. One-hot encode Type
ohe = NumpyOneHotEncoder(drop_first=True)
X_train_cat, cat_cols = ohe.fit_transform(X_train["Type"])   # fit on train
X_test_cat,  _        = ohe.transform(X_test["Type"])         # apply to test

# 5d. Concatenate
X_train_proc = np.hstack([X_train_num_sc, X_train_cat])
X_test_proc  = np.hstack([X_test_num_sc,  X_test_cat])

feature_names = NUMERICAL_FEATURES + cat_cols

print(f"\n[5] Preprocessing (fit on training data only -- leakage prevention):")
print(f"    StandardScaler fitted on {len(NUMERICAL_FEATURES)} numerical features")
print(f"    OneHotEncoder fitted on Type: categories seen = {ohe.categories_}")
print(f"    Output features after encoding ({len(feature_names)}):")
for fn in feature_names:
    print(f"    -> {fn}")
print(f"\n    X_train shape after preprocessing: {X_train_proc.shape}")
print(f"    X_test  shape after preprocessing: {X_test_proc.shape}")

# Sanity-check: means of scaled training data should be ~0, std ~1
print(f"\n    Sanity check (training set after scaling):")
print(f"    Column means  (should be ~0): "
      f"{np.round(X_train_num_sc.mean(axis=0), 4)}")
print(f"    Column stds   (should be ~1): "
      f"{np.round(X_train_num_sc.std(axis=0),  4)}")

# ─────────────────────────────────────────────────────────────
# 6. SAVE ARTEFACTS
# ─────────────────────────────────────────────────────────────
np.save(os.path.join(DATA_OUT, "binary_X_train.npy"), X_train_proc)
np.save(os.path.join(DATA_OUT, "binary_X_test.npy"),  X_test_proc)
np.save(os.path.join(DATA_OUT, "binary_y_train.npy"), y_train.values)
np.save(os.path.join(DATA_OUT, "binary_y_test.npy"),  y_test.values)

scaler.save(os.path.join(MODELS_OUT, "binary_scaler"))
ohe.save(os.path.join(MODELS_OUT, "binary_ohe"))
with open(os.path.join(MODELS_OUT, "binary_feature_names.json"), "w") as f:
    json.dump(feature_names, f)

print(f"\n[6] Saved artefacts:")
print(f"    data/binary_X_train.npy            {X_train_proc.shape}")
print(f"    data/binary_X_test.npy             {X_test_proc.shape}")
print(f"    data/binary_y_train.npy            {y_train.shape}")
print(f"    data/binary_y_test.npy             {y_test.shape}")
print(f"    models/binary_scaler_means/stds.npy")
print(f"    models/binary_ohe.json")
print(f"    models/binary_feature_names.json")

# ─────────────────────────────────────────────────────────────
# 7. IMBALANCE STRATEGY NOTE
# ─────────────────────────────────────────────────────────────
print(f"""
[7] Class imbalance strategy recommendation (for modeling stage):
    - class_weight="balanced" in the classifier (preferred, no data leakage)
    - Primary metrics: ROC-AUC, macro F1, per-class Precision/Recall
    - Accuracy alone is misleading (naive baseline = 96.61%)
    - SMOTE on training set only is a backup option, to be evaluated carefully
""")

print("=" * 65)
print("  Binary task preparation COMPLETE. No models trained.")
print("=" * 65)
