"""
train_binary.py
---------------
TASK 1 — Binary Failure Prediction (Target = 0 / 1)

Trains and evaluates three models:
  1. Logistic Regression  (class_weight="balanced")
  2. Random Forest        (class_weight="balanced")
  3. XGBoost              (scale_pos_weight = majority/minority ratio)

Evaluation metrics (per model):
  Accuracy, Precision, Recall, F1 (class 1), ROC-AUC,
  Confusion Matrix, Classification Report

Best model selected by ROC-AUC + minority-class F1.
Feature importances saved for the best tree-based model.

No test-set information is used for model selection or tuning.
"""

import os, sys, json, warnings
import numpy as np
import pandas as pd
import joblib
warnings.filterwarnings("ignore")

from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, classification_report,
)
import xgboost as xgb

sys.path.insert(0, os.path.dirname(__file__))

PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
DATA_DIR     = os.path.join(PROJECT_ROOT, "data")
MODELS_DIR   = os.path.join(PROJECT_ROOT, "models")
os.makedirs(MODELS_DIR, exist_ok=True)

RESULTS_PATH = os.path.join(MODELS_DIR, "binary_results.json")

# -------------------------------------------------------------
# 1. LOAD PREPROCESSED DATA
# -------------------------------------------------------------
X_train = np.load(os.path.join(DATA_DIR, "binary_X_train.npy"))
X_test  = np.load(os.path.join(DATA_DIR, "binary_X_test.npy"))
y_train = np.load(os.path.join(DATA_DIR, "binary_y_train.npy"))
y_test  = np.load(os.path.join(DATA_DIR, "binary_y_test.npy"))

with open(os.path.join(MODELS_DIR, "binary_feature_names.json")) as f:
    feature_names = json.load(f)

n_neg = int((y_train == 0).sum())
n_pos = int((y_train == 1).sum())
scale_pos_weight = round(n_neg / n_pos, 4)

print("=" * 65)
print("  TASK 1 -- Binary Failure Prediction: Model Training")
print("=" * 65)
print(f"\n  Training set : {X_train.shape[0]} rows, {X_train.shape[1]} features")
print(f"  Test set     : {X_test.shape[0]} rows")
print(f"  Class 0 (train): {n_neg}  |  Class 1 (train): {n_pos}")
print(f"  scale_pos_weight for XGBoost: {scale_pos_weight}")

# -------------------------------------------------------------
# 2. MODEL DEFINITIONS
# -------------------------------------------------------------
models = {
    "Logistic Regression": LogisticRegression(
        class_weight="balanced",
        max_iter=1000,
        random_state=42,
    ),
    "Random Forest": RandomForestClassifier(
        n_estimators=300,
        class_weight="balanced",
        random_state=42,
        n_jobs=-1,
    ),
    "XGBoost": xgb.XGBClassifier(
        n_estimators=300,
        scale_pos_weight=scale_pos_weight,
        eval_metric="logloss",
        random_state=42,
        verbosity=0,
    ),
}

# -------------------------------------------------------------
# 3. TRAIN + EVALUATE
# -------------------------------------------------------------
results = {}

def evaluate(name, model, X_tr, y_tr, X_te, y_te):
    model.fit(X_tr, y_tr)
    y_pred = model.predict(X_te)
    y_prob = (model.predict_proba(X_te)[:, 1]
              if hasattr(model, "predict_proba") else None)

    acc   = accuracy_score(y_te, y_pred)
    prec  = precision_score(y_te, y_pred, zero_division=0)
    rec   = recall_score(y_te, y_pred, zero_division=0)
    f1    = f1_score(y_te, y_pred, zero_division=0)
    auc   = roc_auc_score(y_te, y_prob) if y_prob is not None else None
    cm    = confusion_matrix(y_te, y_pred).tolist()
    cr    = classification_report(y_te, y_pred,
                                  target_names=["No Failure", "Failure"],
                                  zero_division=0)

    print(f"\n{'-'*65}")
    print(f"  Model: {name}")
    print(f"  {'-'*63}")
    print(f"  Accuracy  : {acc:.4f}")
    print(f"  Precision : {prec:.4f}  (Failure class)")
    print(f"  Recall    : {rec:.4f}  (Failure class)")
    print(f"  F1-score  : {f1:.4f}  (Failure class)")
    if auc is not None:
        print(f"  ROC-AUC   : {auc:.4f}")
    print(f"\n  Confusion Matrix:")
    print(f"    TN={cm[0][0]}  FP={cm[0][1]}")
    print(f"    FN={cm[1][0]}  TP={cm[1][1]}")
    print(f"\n  Classification Report:")
    for line in cr.strip().split("\n"):
        print(f"    {line}")

    return {
        "accuracy":  round(acc,  4),
        "precision": round(prec, 4),
        "recall":    round(rec,  4),
        "f1":        round(f1,   4),
        "roc_auc":   round(auc,  4) if auc else None,
        "confusion_matrix": cm,
        "classification_report": cr,
    }

for name, model in models.items():
    results[name] = evaluate(name, model, X_train, y_train, X_test, y_test)
    joblib.dump(model, os.path.join(MODELS_DIR,
                f"binary_{name.lower().replace(' ', '_')}.joblib"))

# -------------------------------------------------------------
# 4. MODEL COMPARISON TABLE
# -------------------------------------------------------------
print(f"\n{'='*65}")
print(f"  BINARY MODEL COMPARISON")
print(f"{'='*65}")
header = f"  {'Model':<25} {'Acc':>6} {'Prec':>6} {'Rec':>6} {'F1':>6} {'AUC':>7}"
print(header)
print(f"  {'-'*60}")
for name, r in results.items():
    auc_str = f"{r['roc_auc']:.4f}" if r['roc_auc'] else "  N/A "
    print(f"  {name:<25} {r['accuracy']:>6.4f} {r['precision']:>6.4f} "
          f"{r['recall']:>6.4f} {r['f1']:>6.4f} {auc_str:>7}")

# -------------------------------------------------------------
# 5. BEST MODEL SELECTION  (by ROC-AUC, then Failure-class F1)
# -------------------------------------------------------------
best_name = max(results,
                key=lambda n: (results[n]["roc_auc"] or 0, results[n]["f1"]))
print(f"\n  Best model (by ROC-AUC + F1): {best_name}")
print(f"    ROC-AUC : {results[best_name]['roc_auc']}")
print(f"    F1      : {results[best_name]['f1']}")
print(f"    Recall  : {results[best_name]['recall']}")

# -------------------------------------------------------------
# 6. FEATURE IMPORTANCE (best tree-based model)
# -------------------------------------------------------------
tree_models = {n: m for n, m in models.items()
               if n in ("Random Forest", "XGBoost")}
best_tree_name = max(tree_models,
                     key=lambda n: (results[n]["roc_auc"] or 0))
best_tree = tree_models[best_tree_name]

if hasattr(best_tree, "feature_importances_"):
    importances = best_tree.feature_importances_
    imp_df = pd.DataFrame({
        "feature": feature_names,
        "importance": importances,
    }).sort_values("importance", ascending=False).reset_index(drop=True)

    print(f"\n  Feature Importances ({best_tree_name}):")
    print(f"  {'Feature':<35} {'Importance':>10}")
    print(f"  {'-'*47}")
    for _, row in imp_df.iterrows():
        bar = "#" * int(row["importance"] * 40)
        print(f"  {row['feature']:<35} {row['importance']:>10.4f}  {bar}")

    imp_df.to_csv(os.path.join(MODELS_DIR,
                  "binary_feature_importance.csv"), index=False)
    print(f"\n  Saved: models/binary_feature_importance.csv")

# -------------------------------------------------------------
# 7. SAVE RESULTS
# -------------------------------------------------------------
summary = {
    "task": "binary_classification",
    "best_model": best_name,
    "models": results,
}
with open(RESULTS_PATH, "w") as f:
    json.dump(summary, f, indent=2)
print(f"\n  Saved: models/binary_results.json")

print(f"\n{'='*65}")
print(f"  Binary model training COMPLETE.")
print(f"{'='*65}")
