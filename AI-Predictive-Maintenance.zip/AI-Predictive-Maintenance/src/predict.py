"""
predict.py
----------
STEP 6 — Command-line Prediction Script
AI-Driven Predictive Maintenance (IBM / Edunet Problem Statement #39)

Usage:
    python src/predict.py

Loads the already-trained models and preprocessing artifacts.
Does NOT retrain or refit anything.

Pipeline for every prediction:
  1. Accept 6 machine inputs from the user.
  2. Validate inputs.
  3. Apply EXACTLY the same preprocessing used during training:
       - StandardScaler (loaded from binary_scaler_means/stds.npy)
       - OneHotEncoder  (loaded from binary_ohe_ohe.json)
  4. Binary XGBoost  → failure probability + 0/1 label.
  5. If failure predicted → Multiclass Random Forest → failure type name.
  6. Display a clear result.
"""

import os
import sys
import json
import numpy as np
import joblib

# ─────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
MODELS_DIR   = os.path.join(PROJECT_ROOT, "models")


# ─────────────────────────────────────────────────────────────
# HELPER — require a file to exist before loading
# ─────────────────────────────────────────────────────────────
def _require(path, label):
    """Raise a clear error if a required file is missing."""
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"[ERROR] Required file not found: {path}\n"
            f"        ({label})\n"
            f"        Make sure all training and preparation steps are complete."
        )
    return path


# ─────────────────────────────────────────────────────────────
# 1. LOAD ALL ARTIFACTS
# ─────────────────────────────────────────────────────────────
def load_artifacts():
    """
    Load:
      - Binary XGBoost model
      - Multiclass Random Forest model
      - Scaler (means + stds from binary prep — same feature set)
      - OneHotEncoder categories (from binary_ohe_ohe.json)
      - Feature names (from binary_feature_names.json)
      - Label encoder classes (from multi_label_encoder_le.json)

    Returns a dict of all loaded objects.
    """
    # Models
    binary_model = joblib.load(
        _require(os.path.join(MODELS_DIR, "binary_xgboost.joblib"),
                 "Binary XGBoost model"))

    multi_model = joblib.load(
        _require(os.path.join(MODELS_DIR, "multi_random_forest.joblib"),
                 "Multiclass Random Forest model"))

    # Scaler parameters (fitted on binary training data)
    scaler_means = np.load(
        _require(os.path.join(MODELS_DIR, "binary_scaler_means.npy"),
                 "Scaler means"))
    scaler_stds = np.load(
        _require(os.path.join(MODELS_DIR, "binary_scaler_stds.npy"),
                 "Scaler standard deviations"))

    # OHE categories
    with open(_require(os.path.join(MODELS_DIR, "binary_ohe_ohe.json"),
                       "One-hot encoder config")) as f:
        ohe_data = json.load(f)

    # Feature names (used to verify column order)
    with open(_require(os.path.join(MODELS_DIR, "binary_feature_names.json"),
                       "Feature names")) as f:
        feature_names = json.load(f)

    # Label encoder for failure types
    with open(_require(os.path.join(MODELS_DIR, "multi_label_encoder_le.json"),
                       "Label encoder")) as f:
        le_data = json.load(f)
    class_names = le_data["classes"]

    return {
        "binary_model":   binary_model,
        "multi_model":    multi_model,
        "scaler_means":   scaler_means,
        "scaler_stds":    scaler_stds,
        "ohe_categories": ohe_data["categories"],   # ['H', 'L', 'M']
        "ohe_drop_first": ohe_data["drop_first"],   # True  → drop 'H'
        "feature_names":  feature_names,            # 7 final feature names
        "class_names":    class_names,              # failure type labels
    }


# ─────────────────────────────────────────────────────────────
# 2. PREPROCESS A SINGLE MACHINE READING
# ─────────────────────────────────────────────────────────────
# Numerical feature order — must exactly match training
NUMERICAL_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]


def preprocess_input(air_temp, proc_temp, rot_speed, torque, tool_wear,
                     machine_type, artifacts):
    """
    Apply the same preprocessing pipeline used during training:
      1. Arrange the 5 numerical features in the correct order.
      2. Scale them using the saved scaler (transform only — no refit).
      3. One-hot encode the Type column (drop_first=True → drop 'H').
      4. Concatenate → final feature vector of length 7.

    Returns a numpy array of shape (1, 7).
    """
    means = artifacts["scaler_means"]
    stds  = artifacts["scaler_stds"]
    cats  = artifacts["ohe_categories"]   # ['H', 'L', 'M']

    # Step 1: numerical array (1×5)
    num_arr = np.array([[air_temp, proc_temp, rot_speed, torque, tool_wear]],
                       dtype=float)

    # Step 2: scale using training parameters (no refit)
    num_scaled = (num_arr - means) / stds

    # Step 3: one-hot encode Type (drop_first → drop cats[0] = 'H')
    if artifacts["ohe_drop_first"]:
        active_cats = cats[1:]          # ['L', 'M']
    else:
        active_cats = cats

    ohe_row = np.zeros((1, len(active_cats)), dtype=float)
    if machine_type in active_cats:
        ohe_row[0, active_cats.index(machine_type)] = 1.0
    # If machine_type == 'H' (the dropped category), ohe_row stays all-zeros

    # Step 4: concatenate → (1, 7)
    X = np.hstack([num_scaled, ohe_row])

    # Sanity check: feature count must match what the model expects
    expected = artifacts["binary_model"].n_features_in_
    if X.shape[1] != expected:
        raise ValueError(
            f"[ERROR] Feature count mismatch!\n"
            f"        Preprocessed vector has {X.shape[1]} features, "
            f"binary model expects {expected}.\n"
            f"        Feature names used: {artifacts['feature_names']}"
        )

    return X


# ─────────────────────────────────────────────────────────────
# 3. BINARY PREDICTION
# ─────────────────────────────────────────────────────────────
def predict_binary(X, artifacts):
    """
    Run the binary XGBoost model.
    Returns:
        label       : 0 (No Failure) or 1 (Failure)
        probability : float — probability of Failure (class 1)
    """
    model = artifacts["binary_model"]
    label = int(model.predict(X)[0])

    if hasattr(model, "predict_proba"):
        prob = float(model.predict_proba(X)[0, 1])
    else:
        prob = float(label)   # fallback if model has no predict_proba

    return label, prob


# ─────────────────────────────────────────────────────────────
# 4. MULTICLASS PREDICTION
# ─────────────────────────────────────────────────────────────
def predict_failure_type(X, artifacts):
    """
    Run the multiclass Random Forest model (on failure rows only).
    Converts the numeric prediction back to the original failure-type
    string using the saved label encoder classes.

    Returns the failure type as a human-readable string.
    """
    model       = artifacts["multi_model"]
    class_names = artifacts["class_names"]

    # The multiclass model was trained on the same 7 features
    expected = model.n_features_in_
    if X.shape[1] != expected:
        raise ValueError(
            f"[ERROR] Feature count mismatch for multiclass model!\n"
            f"        Input has {X.shape[1]} features, model expects {expected}."
        )

    numeric_pred = int(model.predict(X)[0])
    return class_names[numeric_pred]


# ─────────────────────────────────────────────────────────────
# 5. INPUT COLLECTION + VALIDATION
# ─────────────────────────────────────────────────────────────
def get_float_input(prompt, name):
    """Ask the user for a numeric value; re-prompt on invalid input."""
    while True:
        raw = input(prompt).strip()
        try:
            return float(raw)
        except ValueError:
            print(f"  [!] '{raw}' is not a valid number for {name}. Please try again.")


def get_type_input():
    """Ask the user for machine type (H / L / M); re-prompt on invalid input."""
    valid = {"H", "L", "M"}
    while True:
        raw = input("  Machine Type            (H / L / M) : ").strip().upper()
        if raw in valid:
            return raw
        print(f"  [!] '{raw}' is not valid. Please enter H, L, or M.")


def collect_inputs():
    """
    Prompt the user for all 6 machine readings and return them as a tuple.
    Each numeric field is validated to be a real number.
    Type must be H, L, or M.
    """
    print()
    print("  Enter the current machine sensor readings:")
    print()
    air_temp   = get_float_input("  Air temperature [K]     : ", "Air temperature")
    proc_temp  = get_float_input("  Process temperature [K] : ", "Process temperature")
    rot_speed  = get_float_input("  Rotational speed [rpm]  : ", "Rotational speed")
    torque     = get_float_input("  Torque [Nm]             : ", "Torque")
    tool_wear  = get_float_input("  Tool wear [min]         : ", "Tool wear")
    mtype      = get_type_input()
    return air_temp, proc_temp, rot_speed, torque, tool_wear, mtype


# ─────────────────────────────────────────────────────────────
# 6. DISPLAY RESULT
# ─────────────────────────────────────────────────────────────
def display_result(label, probability, failure_type=None):
    """Print the prediction result in a clean, human-readable format."""
    print()
    print("  --------------------------------")
    print("  PREDICTIVE MAINTENANCE RESULT")
    print("  --------------------------------")

    if label == 0:
        print(f"  Failure            : NO")
        print(f"  Failure Probability: {probability * 100:.2f}%")
        print(f"  Status             : Machine operating normally")
    else:
        print(f"  Failure            : YES")
        print(f"  Failure Probability: {probability * 100:.2f}%")
        print(f"  Failure Type       : {failure_type}")
        print(f"  Status             : Maintenance recommended")

    print("  --------------------------------")
    print()


# ─────────────────────────────────────────────────────────────
# 7. MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print()
    print("=" * 50)
    print("  AI PREDICTIVE MAINTENANCE")
    print("  IBM / Edunet Problem Statement #39")
    print("=" * 50)

    # Load all saved artifacts once
    print("\n  Loading models and preprocessing artifacts ...")
    try:
        artifacts = load_artifacts()
    except FileNotFoundError as e:
        print(e)
        sys.exit(1)

    print("  Models loaded successfully.")
    print(f"  Features     : {artifacts['feature_names']}")
    print(f"  Failure types: {artifacts['class_names']}")

    # Prediction loop — ask user if they want to predict again
    while True:
        # Collect and validate inputs
        try:
            (air_temp, proc_temp, rot_speed,
             torque, tool_wear, mtype) = collect_inputs()
        except (EOFError, KeyboardInterrupt):
            print("\n  Exiting. Goodbye!")
            break

        # Preprocess
        try:
            X = preprocess_input(air_temp, proc_temp, rot_speed,
                                 torque, tool_wear, mtype, artifacts)
        except ValueError as e:
            print(e)
            sys.exit(1)

        # Binary prediction (Step 1)
        label, prob = predict_binary(X, artifacts)

        # Multiclass prediction only if failure is detected (Step 2 / 3)
        failure_type = None
        if label == 1:
            failure_type = predict_failure_type(X, artifacts)

        # Show result
        display_result(label, prob, failure_type)

        # Ask to continue
        again = input("  Run another prediction? (y/n): ").strip().lower()
        if again != "y":
            print("\n  Exiting. Goodbye!")
            break


if __name__ == "__main__":
    main()
