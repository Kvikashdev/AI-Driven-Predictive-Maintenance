"""
preprocessing.py
----------------
Shared preprocessing definitions for the AI-Driven Predictive Maintenance project.

Implemented with pandas + numpy only (no scikit-learn dependency) so the code
runs in environments where scipy/sklearn DLLs may be blocked.

Provides:
  - Feature / column constants
  - StandardScaler   : fits on training data, transforms both splits
  - OneHotEncoder    : fits on training data, transforms both splits
  - stratified_split : reproduces sklearn stratify= behaviour
  - load_raw()       : loads the raw CSV

No model training happens here.
"""

import os
import json
import numpy as np
import pandas as pd

# ─────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────
PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
DATA_PATH    = os.path.join(PROJECT_ROOT, "data", "predictive_maintenance.csv")

# ─────────────────────────────────────────────────────────────
# COLUMN DEFINITIONS
# ─────────────────────────────────────────────────────────────
IDENTIFIER_COLS = ["UDI", "Product ID"]

CATEGORICAL_FEATURES = ["Type"]                   # L / M / H

NUMERICAL_FEATURES = [
    "Air temperature [K]",
    "Process temperature [K]",
    "Rotational speed [rpm]",
    "Torque [Nm]",
    "Tool wear [min]",
]

BINARY_TARGET     = "Target"
MULTICLASS_TARGET = "Failure Type"
NO_FAILURE_LABEL  = "No Failure"

INPUT_FEATURES = NUMERICAL_FEATURES + CATEGORICAL_FEATURES   # 5 num + 1 cat


# ─────────────────────────────────────────────────────────────
# DATA LOADER
# ─────────────────────────────────────────────────────────────
def load_raw() -> pd.DataFrame:
    df = pd.read_csv(DATA_PATH)
    df.columns = [c.lstrip("\ufeff").strip() for c in df.columns]
    return df


# ─────────────────────────────────────────────────────────────
# STRATIFIED SPLIT  (pandas / numpy — no sklearn)
# ─────────────────────────────────────────────────────────────
def stratified_split(X: pd.DataFrame, y: pd.Series,
                     test_size: float = 0.20,
                     random_state: int = 42):
    """
    80/20 stratified split.
    Returns X_train, X_test, y_train, y_test as DataFrames / Series.
    """
    rng = np.random.default_rng(random_state)
    train_idx, test_idx = [], []

    for cls in sorted(y.unique()):
        cls_idx = y[y == cls].index.tolist()
        rng.shuffle(cls_idx)
        n_test = max(1, round(len(cls_idx) * test_size))
        test_idx.extend(cls_idx[:n_test])
        train_idx.extend(cls_idx[n_test:])

    # shuffle the combined indices so order is random
    train_idx = list(rng.permutation(train_idx))
    test_idx  = list(rng.permutation(test_idx))

    return (X.loc[train_idx].reset_index(drop=True),
            X.loc[test_idx].reset_index(drop=True),
            y.loc[train_idx].reset_index(drop=True),
            y.loc[test_idx].reset_index(drop=True))


# ─────────────────────────────────────────────────────────────
# STANDARD SCALER  (fit on train, transform both)
# ─────────────────────────────────────────────────────────────
class NumpyStandardScaler:
    """Mean/std scaler fitted on training data only."""

    def __init__(self):
        self.means_ = None
        self.stds_  = None

    def fit(self, X: np.ndarray):
        self.means_ = X.mean(axis=0)
        self.stds_  = X.std(axis=0, ddof=0)
        self.stds_[self.stds_ == 0] = 1.0   # avoid division by zero
        return self

    def transform(self, X: np.ndarray) -> np.ndarray:
        return (X - self.means_) / self.stds_

    def fit_transform(self, X: np.ndarray) -> np.ndarray:
        return self.fit(X).transform(X)

    def save(self, path: str):
        np.save(path + "_means.npy", self.means_)
        np.save(path + "_stds.npy",  self.stds_)

    @classmethod
    def load(cls, path: str):
        obj = cls()
        obj.means_ = np.load(path + "_means.npy")
        obj.stds_  = np.load(path + "_stds.npy")
        return obj


# ─────────────────────────────────────────────────────────────
# ONE-HOT ENCODER  (fit on train, transform both)
# ─────────────────────────────────────────────────────────────
class NumpyOneHotEncoder:
    """
    One-hot encoder for a single categorical column.
    Drops the first category to avoid multicollinearity (drop='first').
    Unknown categories at transform time produce all-zero rows.
    """

    def __init__(self, drop_first: bool = True):
        self.drop_first = drop_first
        self.categories_ = None   # ordered list of all categories seen at fit time

    def fit(self, series: pd.Series):
        self.categories_ = sorted(series.dropna().unique().tolist())
        return self

    def transform(self, series: pd.Series) -> tuple:
        """Returns (numpy array, list of column names)."""
        cats = self.categories_[1:] if self.drop_first else self.categories_
        arr = np.zeros((len(series), len(cats)), dtype=float)
        for i, val in enumerate(series):
            if val in cats:
                arr[i, cats.index(val)] = 1.0
        col_names = [f"Type_{c}" for c in cats]
        return arr, col_names

    def fit_transform(self, series: pd.Series) -> tuple:
        return self.fit(series).transform(series)

    def save(self, path: str):
        with open(path + "_ohe.json", "w") as f:
            json.dump({"categories": self.categories_,
                       "drop_first": self.drop_first}, f)

    @classmethod
    def load(cls, path: str):
        with open(path + "_ohe.json") as f:
            data = json.load(f)
        obj = cls(drop_first=data["drop_first"])
        obj.categories_ = data["categories"]
        return obj


# ─────────────────────────────────────────────────────────────
# LABEL ENCODER  (for Failure Type)
# ─────────────────────────────────────────────────────────────
class NumpyLabelEncoder:
    """Ordinal encoder for the Failure Type target column."""

    def __init__(self):
        self.classes_ = None
        self._map     = None

    def fit(self, series: pd.Series):
        self.classes_ = sorted(series.dropna().unique().tolist())
        self._map     = {c: i for i, c in enumerate(self.classes_)}
        return self

    def transform(self, series: pd.Series) -> np.ndarray:
        return np.array([self._map[v] for v in series])

    def fit_transform(self, series: pd.Series) -> np.ndarray:
        return self.fit(series).transform(series)

    def inverse_transform(self, arr) -> list:
        return [self.classes_[i] for i in arr]

    def save(self, path: str):
        with open(path + "_le.json", "w") as f:
            json.dump({"classes": self.classes_}, f)

    @classmethod
    def load(cls, path: str):
        with open(path + "_le.json") as f:
            data = json.load(f)
        obj = cls()
        obj.classes_ = data["classes"]
        obj._map      = {c: i for i, c in enumerate(obj.classes_)}
        return obj
