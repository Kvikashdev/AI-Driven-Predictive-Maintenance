"""
prepare_multiclass.py
---------------------
Data preparation for TASK 2: Failure Type Classification.

Key design decision:
  Only rows where an actual failure occurred (Failure Type != "No Failure") are used.
  This is a 5-class problem:
    Heat Dissipation Failure, Overstrain Failure, Power Failure,
    Random Failures, Tool Wear Failure.

Steps performed:
  1. Load raw dataset
  2. Filter to failure rows only (Failure Type != "No Failure")
  3. Drop identifier columns and Target (binary label -- leakage risk)
  4. Encode Failure Type label with NumpyLabelEncoder
  5. 80/20 stratified train/test split (random_state=42)
  6. Fit scaler & OHE on X_train ONLY, transform both splits
  7. Document class distribution and imbalance
  8. Save processed arrays and encoder params to data/ and models/

No model is trained here.
"""

import os
import sys
import numpy as np
import pandas as pd
import json

sys.path.insert(0, os.path.dirname(__file__))
from preprocessing import (
    load_raw, stratified_split,
    NumpyStandardScaler, NumpyOneHotEncoder, NumpyLabelEncoder,
    INPUT_FEATURES, NUMERICAL_FEATURES, CATEGORICAL_FEATURES,
    BINARY_TARGET, MULTICLASS_TARGET, NO_FAILURE_LABEL,
)

PROJECT_ROOT = os.path.join(os.path.dirname(__file__), "..")
DATA_OUT     = os.path.join(PROJECT_ROOT, "data")
MODELS_OUT   = os.path.join(PROJECT_ROOT, "models")
os.makedirs(DATA_OUT,   exist_ok=True)
os.makedirs(MODELS_OUT, exist_ok=True)

RANDOM_STATE = 42
TEST_SIZE    = 0.20

# ─────────────────────────────────────────────────────────────
print("=" * 65)
print("  TASK 2 -- Failure Type Classification: Data Preparation")
print("=" * 65)

# ─────────────────────────────────────────────────────────────
# 1. LOAD
# ─────────────────────────────────────────────────────────────
df = load_raw()
print(f"\n[1] Loaded dataset: {df.shape[0]} rows x {df.shape[1]} columns")

# ─────────────────────────────────────────────────────────────
# 2. FILTER TO FAILURE ROWS ONLY
# ─────────────────────────────────────────────────────────────
df_fail = df[df[MULTICLASS_TARGET] != NO_FAILURE_LABEL].copy().reset_index(drop=True)

print(f"\n[2] Filtered to failure rows only (Failure Type != 'No Failure'):")
print(f"    Rows retained : {len(df_fail)}")
print(f"    Rows dropped  : {len(df) - len(df_fail)}  (all 'No Failure')")
print(f"\n    Failure type counts in filtered dataset:")
fc = df_fail[MULTICLASS_TARGET].value_counts()
for label, cnt in fc.items():
    pct = cnt / len(df_fail) * 100
    print(f"    {label:<30}: {cnt:>4}  ({pct:.1f}%)")

# ─────────────────────────────────────────────────────────────
# 3. FEATURE / TARGET SELECTION
# ─────────────────────────────────────────────────────────────
X     = df_fail[INPUT_FEATURES].copy()
y_raw = df_fail[MULTICLASS_TARGET].copy()

print(f"\n[3] Features selected ({len(INPUT_FEATURES)}):")
for f in INPUT_FEATURES:
    print(f"    + {f}")
print(f"\n    Columns removed:")
print(f"    - UDI          (identifier)")
print(f"    - Product ID   (identifier)")
print(f"    - Target       (binary label -- data leakage if used as input)")

# ─────────────────────────────────────────────────────────────
# 4. LABEL ENCODE Failure Type
# ─────────────────────────────────────────────────────────────
le = NumpyLabelEncoder()
y  = pd.Series(le.fit_transform(y_raw), name=MULTICLASS_TARGET)

print(f"\n[4] Failure Type label encoding:")
for idx, cls in enumerate(le.classes_):
    print(f"    {idx} -> {cls}")

# ─────────────────────────────────────────────────────────────
# 5. TRAIN / TEST SPLIT  (stratified on Failure Type)
# ─────────────────────────────────────────────────────────────
# "Random Failures" has 18 samples: 80/20 -> ~14 train / ~4 test. Safe.
X_train, X_test, y_train, y_test = stratified_split(
    X, y, test_size=TEST_SIZE, random_state=RANDOM_STATE
)

print(f"\n[5] Train/test split (80/20, stratified on Failure Type):")
print(f"    Training set : {len(X_train)} rows")
print(f"    Test set     : {len(X_test)} rows")

# ─────────────────────────────────────────────────────────────
# 6. CLASS DISTRIBUTION
# ─────────────────────────────────────────────────────────────
def class_report(y_series, split_name, label_encoder):
    vc  = y_series.value_counts().sort_index()
    pct = y_series.value_counts(normalize=True).sort_index() * 100
    print(f"\n[6] Class distribution -- {split_name}:")
    for cls in vc.index:
        print(f"    Class {cls} ({label_encoder.classes_[cls]:<30}): "
              f"{vc[cls]:>3}  ({pct[cls]:.1f}%)")
    ratio = vc.max() / max(vc.min(), 1)
    print(f"    Imbalance ratio (within failures): {ratio:.2f}:1")

class_report(y_train, "Training set", le)
class_report(y_test,  "Test set",     le)

# ─────────────────────────────────────────────────────────────
# 7. PREPROCESSING  (fit ONLY on training data)
# ─────────────────────────────────────────────────────────────

# 7a. Extract numpy arrays for numerical columns
X_train_num = X_train[NUMERICAL_FEATURES].values.astype(float)
X_test_num  = X_test[NUMERICAL_FEATURES].values.astype(float)

# 7b. Scale numerical features
scaler = NumpyStandardScaler()
X_train_num_sc = scaler.fit_transform(X_train_num)
X_test_num_sc  = scaler.transform(X_test_num)

# 7c. One-hot encode Type
ohe = NumpyOneHotEncoder(drop_first=True)
X_train_cat, cat_cols = ohe.fit_transform(X_train["Type"])
X_test_cat,  _        = ohe.transform(X_test["Type"])

# 7d. Concatenate
X_train_proc = np.hstack([X_train_num_sc, X_train_cat])
X_test_proc  = np.hstack([X_test_num_sc,  X_test_cat])

feature_names = NUMERICAL_FEATURES + cat_cols

print(f"\n[7] Preprocessing (fit on training data only -- leakage prevention):")
print(f"    StandardScaler fitted on {len(NUMERICAL_FEATURES)} numerical features")
print(f"    OneHotEncoder fitted on Type: categories seen = {ohe.categories_}")
print(f"    Output features after encoding ({len(feature_names)}):")
for fn in feature_names:
    print(f"    -> {fn}")
print(f"\n    X_train shape after preprocessing: {X_train_proc.shape}")
print(f"    X_test  shape after preprocessing: {X_test_proc.shape}")

# Sanity check
print(f"\n    Sanity check (training set after scaling):")
print(f"    Column means  (should be ~0): "
      f"{np.round(X_train_num_sc.mean(axis=0), 4)}")
print(f"    Column stds   (should be ~1): "
      f"{np.round(X_train_num_sc.std(axis=0),  4)}")

# ─────────────────────────────────────────────────────────────
# 8. SAVE ARTEFACTS
# ─────────────────────────────────────────────────────────────
np.save(os.path.join(DATA_OUT, "multi_X_train.npy"), X_train_proc)
np.save(os.path.join(DATA_OUT, "multi_X_test.npy"),  X_test_proc)
np.save(os.path.join(DATA_OUT, "multi_y_train.npy"), y_train.values)
np.save(os.path.join(DATA_OUT, "multi_y_test.npy"),  y_test.values)

scaler.save(os.path.join(MODELS_OUT, "multi_scaler"))
ohe.save(os.path.join(MODELS_OUT, "multi_ohe"))
le.save(os.path.join(MODELS_OUT, "multi_label_encoder"))
with open(os.path.join(MODELS_OUT, "multi_feature_names.json"), "w") as f:
    json.dump(feature_names, f)

print(f"\n[8] Saved artefacts:")
print(f"    data/multi_X_train.npy              {X_train_proc.shape}")
print(f"    data/multi_X_test.npy               {X_test_proc.shape}")
print(f"    data/multi_y_train.npy              {y_train.shape}")
print(f"    data/multi_y_test.npy               {y_test.shape}")
print(f"    models/multi_scaler_means/stds.npy")
print(f"    models/multi_ohe.json")
print(f"    models/multi_label_encoder.json")
print(f"    models/multi_feature_names.json")

# ─────────────────────────────────────────────────────────────
# 9. IMBALANCE STRATEGY NOTE
# ─────────────────────────────────────────────────────────────
print(f"""
[9] Class imbalance strategy recommendation (for modeling stage):
    - class_weight="balanced" in the classifier (preferred)
    - Primary metric: macro F1 and per-class Precision/Recall/Support
    - Accuracy is unreliable here; macro F1 is the headline metric
    - "Random Failures" has only ~18 samples (~14 train / ~4 test)
      -> low recall on this class is expected; treat as known limitation
    - SMOTE on training set only is a backup option, to be evaluated carefully
""")

print("=" * 65)
print("  Multiclass task preparation COMPLETE. No models trained.")
print("=" * 65)
