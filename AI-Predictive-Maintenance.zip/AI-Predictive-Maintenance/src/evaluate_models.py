"""
evaluate_models.py
------------------
STEP 5 — Complete Model Evaluation, Visualization, and Results Reporting

Loads the already-trained best models and existing test datasets.
Does NOT retrain, refit, or modify anything.

Best models selected during training:
  Task 1 (Binary)     : XGBoost  (binary_xgboost.joblib)
  Task 2 (Multiclass) : Random Forest  (multi_random_forest.joblib)
"""

import os
import sys
import json
import numpy as np
import matplotlib
matplotlib.use("Agg")          # non-interactive backend — no display needed
import matplotlib.pyplot as plt
import joblib

from sklearn.metrics import (
    accuracy_score,
    precision_score,
    recall_score,
    f1_score,
    roc_auc_score,
    roc_curve,
    confusion_matrix,
    classification_report,
)

# ─────────────────────────────────────────────────────────────
# PATHS
# ─────────────────────────────────────────────────────────────
PROJECT_ROOT  = os.path.join(os.path.dirname(__file__), "..")
DATA_DIR      = os.path.join(PROJECT_ROOT, "data")
MODELS_DIR    = os.path.join(PROJECT_ROOT, "models")
PLOTS_DIR     = os.path.join(PROJECT_ROOT, "results", "plots")
EVAL_DIR      = os.path.join(PROJECT_ROOT, "results", "evaluation")

os.makedirs(PLOTS_DIR, exist_ok=True)
os.makedirs(EVAL_DIR,  exist_ok=True)


# ─────────────────────────────────────────────────────────────
# HELPER — safe file loader with clear error messages
# ─────────────────────────────────────────────────────────────
def _require(path, label):
    """Raise a clear error if a required file is missing."""
    if not os.path.isfile(path):
        raise FileNotFoundError(
            f"[ERROR] Required file not found: {path}\n"
            f"        ({label})\n"
            f"        Make sure all training steps have been completed."
        )
    return path


# ─────────────────────────────────────────────────────────────
# 1. LOAD ALL MODELS AND ARTEFACTS
# ─────────────────────────────────────────────────────────────
def load_models():
    """
    Load the best binary model (XGBoost) and best multiclass model
    (Random Forest), plus their associated test data and feature names.
    """
    print("\n[1] Loading models and test data ...")

    # --- Binary ---
    binary_model = joblib.load(
        _require(os.path.join(MODELS_DIR, "binary_xgboost.joblib"),
                 "Binary XGBoost model"))

    X_bin_test = np.load(
        _require(os.path.join(DATA_DIR, "binary_X_test.npy"),
                 "Binary test features"))
    y_bin_test = np.load(
        _require(os.path.join(DATA_DIR, "binary_y_test.npy"),
                 "Binary test labels"))

    with open(_require(os.path.join(MODELS_DIR, "binary_feature_names.json"),
                       "Binary feature names")) as f:
        binary_feature_names = json.load(f)

    # Shape sanity check
    expected_bin = binary_model.n_features_in_
    if X_bin_test.shape[1] != expected_bin:
        raise ValueError(
            f"[ERROR] Feature mismatch for Binary model!\n"
            f"        Test data has {X_bin_test.shape[1]} features, "
            f"model expects {expected_bin}.\n"
            f"        Check that prepare_binary.py was run with the current pipeline."
        )

    # --- Multiclass ---
    multi_model = joblib.load(
        _require(os.path.join(MODELS_DIR, "multi_random_forest.joblib"),
                 "Multiclass Random Forest model"))

    X_multi_test = np.load(
        _require(os.path.join(DATA_DIR, "multi_X_test.npy"),
                 "Multiclass test features"))
    y_multi_test = np.load(
        _require(os.path.join(DATA_DIR, "multi_y_test.npy"),
                 "Multiclass test labels"))

    with open(_require(os.path.join(MODELS_DIR, "multi_feature_names.json"),
                       "Multiclass feature names")) as f:
        multi_feature_names = json.load(f)

    with open(_require(os.path.join(MODELS_DIR, "multi_label_encoder_le.json"),
                       "Multiclass label encoder")) as f:
        le_data = json.load(f)
    class_names = le_data["classes"]   # list of original failure-type strings

    # Shape sanity check
    expected_multi = multi_model.n_features_in_
    if X_multi_test.shape[1] != expected_multi:
        raise ValueError(
            f"[ERROR] Feature mismatch for Multiclass model!\n"
            f"        Test data has {X_multi_test.shape[1]} features, "
            f"model expects {expected_multi}.\n"
            f"        Check that prepare_multiclass.py was run with the current pipeline."
        )

    print(f"    Binary  model loaded  — test set shape: {X_bin_test.shape}")
    print(f"    Multi   model loaded  — test set shape: {X_multi_test.shape}")
    print(f"    Binary  feature count : {len(binary_feature_names)}")
    print(f"    Multi   feature count : {len(multi_feature_names)}")
    print(f"    Failure type classes  : {class_names}")

    return (binary_model,  X_bin_test,   y_bin_test,   binary_feature_names,
            multi_model,   X_multi_test, y_multi_test, multi_feature_names,
            class_names)


# ─────────────────────────────────────────────────────────────
# 2. BINARY EVALUATION
# ─────────────────────────────────────────────────────────────
def evaluate_binary(model, X_test, y_test):
    """
    Evaluate the binary XGBoost model on the held-out test set.
    Returns a dict of all metrics plus raw predictions for plotting.
    """
    print("\n[2] Evaluating Binary XGBoost model ...")

    y_pred = model.predict(X_test)
    y_prob = model.predict_proba(X_test)[:, 1]   # probability of Failure class

    acc   = accuracy_score(y_test, y_pred)
    prec  = precision_score(y_test, y_pred, zero_division=0)
    rec   = recall_score(y_test, y_pred, zero_division=0)
    f1    = f1_score(y_test, y_pred, zero_division=0)
    auc   = roc_auc_score(y_test, y_prob)
    cm    = confusion_matrix(y_test, y_pred)
    cr    = classification_report(y_test, y_pred,
                                  target_names=["No Failure", "Failure"],
                                  zero_division=0)
    fpr, tpr, _ = roc_curve(y_test, y_prob)

    print(f"    Accuracy  : {acc:.4f}")
    print(f"    Precision : {prec:.4f}")
    print(f"    Recall    : {rec:.4f}")
    print(f"    F1        : {f1:.4f}")
    print(f"    ROC-AUC   : {auc:.4f}")

    return {
        "accuracy":  round(float(acc),  4),
        "precision": round(float(prec), 4),
        "recall":    round(float(rec),  4),
        "f1":        round(float(f1),   4),
        "roc_auc":   round(float(auc),  4),
        "confusion_matrix": cm.tolist(),
        "classification_report": cr,
        # raw arrays for plotting only — not saved to JSON
        "_cm":  cm,
        "_fpr": fpr,
        "_tpr": tpr,
    }


# ─────────────────────────────────────────────────────────────
# 3. MULTICLASS EVALUATION
# ─────────────────────────────────────────────────────────────
def evaluate_multiclass(model, X_test, y_test, class_names):
    """
    Evaluate the multiclass Random Forest model on the held-out test set.
    Returns a dict of all metrics plus the confusion matrix for plotting.
    """
    print("\n[3] Evaluating Multiclass Random Forest model ...")

    y_pred = model.predict(X_test)

    acc      = accuracy_score(y_test, y_pred)
    mac_p    = precision_score(y_test, y_pred, average="macro",    zero_division=0)
    mac_r    = recall_score   (y_test, y_pred, average="macro",    zero_division=0)
    mac_f1   = f1_score       (y_test, y_pred, average="macro",    zero_division=0)
    wgt_p    = precision_score(y_test, y_pred, average="weighted", zero_division=0)
    wgt_r    = recall_score   (y_test, y_pred, average="weighted", zero_division=0)
    wgt_f1   = f1_score       (y_test, y_pred, average="weighted", zero_division=0)
    cm       = confusion_matrix(y_test, y_pred)
    cr       = classification_report(y_test, y_pred,
                                     target_names=class_names,
                                     zero_division=0)

    # Per-class metrics
    per_class_p  = precision_score(y_test, y_pred, average=None, zero_division=0)
    per_class_r  = recall_score   (y_test, y_pred, average=None, zero_division=0)
    per_class_f  = f1_score       (y_test, y_pred, average=None, zero_division=0)

    per_class = {
        class_names[i]: {
            "precision": round(float(per_class_p[i]), 4),
            "recall":    round(float(per_class_r[i]), 4),
            "f1":        round(float(per_class_f[i]), 4),
        }
        for i in range(len(class_names))
    }

    print(f"    Accuracy         : {acc:.4f}")
    print(f"    Macro Precision  : {mac_p:.4f}")
    print(f"    Macro Recall     : {mac_r:.4f}")
    print(f"    Macro F1         : {mac_f1:.4f}")
    print(f"    Weighted F1      : {wgt_f1:.4f}")
    print(f"\n    Per-class F1:")
    for cls, vals in per_class.items():
        flag = "  *** LOW ***" if vals["f1"] < 0.30 else ""
        print(f"      {cls:<30}: {vals['f1']:.4f}{flag}")

    return {
        "accuracy":          round(float(acc),   4),
        "macro_precision":   round(float(mac_p), 4),
        "macro_recall":      round(float(mac_r), 4),
        "macro_f1":          round(float(mac_f1),4),
        "weighted_precision":round(float(wgt_p), 4),
        "weighted_recall":   round(float(wgt_r), 4),
        "weighted_f1":       round(float(wgt_f1),4),
        "per_class":         per_class,
        "confusion_matrix":  cm.tolist(),
        "classification_report": cr,
        # raw array for plotting
        "_cm": cm,
    }


# ─────────────────────────────────────────────────────────────
# 4. PLOT — CONFUSION MATRIX
# ─────────────────────────────────────────────────────────────
def plot_confusion_matrix(cm, class_names, title, save_path):
    """
    Draw a confusion matrix with cell values and axis labels.
    Works for both binary (2×2) and multiclass (N×N).
    """
    fig, ax = plt.subplots(figsize=(max(5, len(class_names) * 1.6),
                                    max(4, len(class_names) * 1.4)))

    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    plt.colorbar(im, ax=ax)

    ax.set_xticks(range(len(class_names)))
    ax.set_yticks(range(len(class_names)))
    ax.set_xticklabels(class_names, rotation=30, ha="right", fontsize=9)
    ax.set_yticklabels(class_names, fontsize=9)

    # Print value inside each cell
    thresh = cm.max() / 2.0
    for i in range(cm.shape[0]):
        for j in range(cm.shape[1]):
            ax.text(j, i, str(cm[i, j]),
                    ha="center", va="center",
                    color="white" if cm[i, j] > thresh else "black",
                    fontsize=11, fontweight="bold")

    ax.set_title(title, fontsize=13, pad=12)
    ax.set_ylabel("Actual Label", fontsize=10)
    ax.set_xlabel("Predicted Label", fontsize=10)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"    Saved: {save_path}")


# ─────────────────────────────────────────────────────────────
# 5. PLOT — ROC CURVE (binary only)
# ─────────────────────────────────────────────────────────────
def plot_roc_curve(fpr, tpr, auc_score, save_path):
    """Draw a clean ROC curve for the binary classifier."""
    fig, ax = plt.subplots(figsize=(6, 5))

    ax.plot(fpr, tpr,
            label=f"XGBoost  (AUC = {auc_score:.4f})",
            linewidth=2)
    ax.plot([0, 1], [0, 1], linestyle="--", linewidth=1, label="Random baseline")

    ax.set_title("ROC Curve — Binary Failure Prediction (XGBoost)", fontsize=12)
    ax.set_xlabel("False Positive Rate", fontsize=10)
    ax.set_ylabel("True Positive Rate", fontsize=10)
    ax.legend(loc="lower right", fontsize=9)
    ax.set_xlim([0.0, 1.0])
    ax.set_ylim([0.0, 1.02])
    ax.grid(True, linestyle="--", alpha=0.5)

    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"    Saved: {save_path}")


# ─────────────────────────────────────────────────────────────
# 6. PLOT — FEATURE IMPORTANCE
# ─────────────────────────────────────────────────────────────
def plot_feature_importance(importances, feature_names, title, save_path):
    """
    Horizontal bar chart of feature importances, sorted descending.
    Uses the actual feature names from the saved JSON artefact.
    """
    # Sort by importance
    order = np.argsort(importances)
    sorted_names  = [feature_names[i] for i in order]
    sorted_values = importances[order]

    fig, ax = plt.subplots(figsize=(8, max(4, len(feature_names) * 0.55)))

    bars = ax.barh(range(len(sorted_names)), sorted_values)
    ax.set_yticks(range(len(sorted_names)))
    ax.set_yticklabels(sorted_names, fontsize=9)
    ax.set_xlabel("Importance Score", fontsize=10)
    ax.set_title(title, fontsize=12, pad=10)

    # Annotate each bar with its value
    for bar, val in zip(bars, sorted_values):
        ax.text(bar.get_width() + 0.002, bar.get_y() + bar.get_height() / 2,
                f"{val:.4f}", va="center", ha="left", fontsize=8)

    ax.set_xlim(0, sorted_values.max() * 1.18)
    plt.tight_layout()
    plt.savefig(save_path, dpi=150)
    plt.close(fig)
    print(f"    Saved: {save_path}")


# ─────────────────────────────────────────────────────────────
# 7. GENERATE ALL PLOTS
# ─────────────────────────────────────────────────────────────
def generate_plots(bin_results, multi_results,
                   bin_model, multi_model,
                   binary_feature_names, multi_feature_names,
                   class_names):
    """Create and save all five required plot files."""
    print("\n[4] Generating plots ...")

    # 4a. Binary confusion matrix
    plot_confusion_matrix(
        bin_results["_cm"],
        ["No Failure", "Failure"],
        "Confusion Matrix — Binary Failure Prediction (XGBoost)",
        os.path.join(PLOTS_DIR, "binary_confusion_matrix.png"),
    )

    # 4b. ROC curve
    plot_roc_curve(
        bin_results["_fpr"],
        bin_results["_tpr"],
        bin_results["roc_auc"],
        os.path.join(PLOTS_DIR, "binary_roc_curve.png"),
    )

    # 4c. Binary feature importance (from XGBoost)
    bin_imp = bin_model.feature_importances_
    plot_feature_importance(
        bin_imp,
        binary_feature_names,
        "Feature Importance — Binary Failure Prediction (XGBoost)",
        os.path.join(PLOTS_DIR, "binary_feature_importance.png"),
    )

    # 4d. Multiclass confusion matrix
    plot_confusion_matrix(
        multi_results["_cm"],
        class_names,
        "Confusion Matrix — Failure Type Classification (Random Forest)",
        os.path.join(PLOTS_DIR, "multiclass_confusion_matrix.png"),
    )

    # 4e. Multiclass feature importance (from Random Forest)
    multi_imp = multi_model.feature_importances_
    plot_feature_importance(
        multi_imp,
        multi_feature_names,
        "Feature Importance — Failure Type Classification (Random Forest)",
        os.path.join(PLOTS_DIR, "multiclass_feature_importance.png"),
    )


# ─────────────────────────────────────────────────────────────
# 8. SAVE JSON + TEXT REPORT
# ─────────────────────────────────────────────────────────────
def save_results(bin_results, multi_results):
    """
    Save:
      - results/evaluation/model_evaluation.json
      - results/evaluation/evaluation_report.txt
    """
    print("\n[5] Saving evaluation results ...")

    # ── JSON ─────────────────────────────────────────────────
    json_data = {
        "binary": {
            "model":                 "XGBoost",
            "accuracy":              bin_results["accuracy"],
            "precision":             bin_results["precision"],
            "recall":                bin_results["recall"],
            "f1":                    bin_results["f1"],
            "roc_auc":               bin_results["roc_auc"],
            "confusion_matrix":      bin_results["confusion_matrix"],
            "classification_report": bin_results["classification_report"],
        },
        "multiclass": {
            "model":                  "Random Forest",
            "accuracy":               multi_results["accuracy"],
            "macro_precision":        multi_results["macro_precision"],
            "macro_recall":           multi_results["macro_recall"],
            "macro_f1":               multi_results["macro_f1"],
            "weighted_precision":     multi_results["weighted_precision"],
            "weighted_recall":        multi_results["weighted_recall"],
            "weighted_f1":            multi_results["weighted_f1"],
            "per_class":              multi_results["per_class"],
            "confusion_matrix":       multi_results["confusion_matrix"],
            "classification_report":  multi_results["classification_report"],
        },
    }

    json_path = os.path.join(EVAL_DIR, "model_evaluation.json")
    with open(json_path, "w") as f:
        json.dump(json_data, f, indent=2)
    print(f"    Saved: {json_path}")

    # ── Text report ──────────────────────────────────────────
    cm_bin   = np.array(bin_results["confusion_matrix"])
    tn, fp   = cm_bin[0, 0], cm_bin[0, 1]
    fn, tp   = cm_bin[1, 0], cm_bin[1, 1]

    lines = []
    lines.append("=" * 65)
    lines.append("  AI PREDICTIVE MAINTENANCE — MODEL EVALUATION REPORT")
    lines.append("  IBM / Edunet Problem Statement #39")
    lines.append("=" * 65)
    lines.append("")
    lines.append("  Note: All metrics are calculated from the saved test dataset.")
    lines.append("  No model was retrained or refitted for this report.")
    lines.append("")
    lines.append("─" * 65)
    lines.append("  TASK 1 — BINARY FAILURE PREDICTION")
    lines.append("  Model: XGBoost (best by ROC-AUC + Failure-class F1)")
    lines.append("─" * 65)
    lines.append(f"  Accuracy  : {bin_results['accuracy']:.4f}")
    lines.append(f"  Precision : {bin_results['precision']:.4f}  (Failure class)")
    lines.append(f"  Recall    : {bin_results['recall']:.4f}  (Failure class)")
    lines.append(f"  F1-score  : {bin_results['f1']:.4f}  (Failure class)")
    lines.append(f"  ROC-AUC   : {bin_results['roc_auc']:.4f}")
    lines.append("")
    lines.append("  Confusion Matrix:")
    lines.append(f"    True  Negative (TN): {tn:>5}  — correctly predicted No Failure")
    lines.append(f"    False Positive (FP): {fp:>5}  — predicted Failure, was No Failure")
    lines.append(f"    False Negative (FN): {fn:>5}  — predicted No Failure, was Failure")
    lines.append(f"    True  Positive (TP): {tp:>5}  — correctly predicted Failure")
    lines.append("")
    lines.append("  Classification Report:")
    for line in bin_results["classification_report"].strip().split("\n"):
        lines.append(f"    {line}")
    lines.append("")
    lines.append("  Class imbalance note:")
    lines.append("    The dataset is heavily imbalanced (~96–97% No Failure).")
    lines.append("    Accuracy alone is misleading — ROC-AUC and F1 are the")
    lines.append("    primary evaluation metrics for this task.")
    lines.append("")
    lines.append("─" * 65)
    lines.append("  TASK 2 — FAILURE TYPE CLASSIFICATION (5-class)")
    lines.append("  Model: Random Forest (best by Macro F1)")
    lines.append("─" * 65)
    lines.append(f"  Accuracy           : {multi_results['accuracy']:.4f}")
    lines.append(f"  Macro Precision    : {multi_results['macro_precision']:.4f}")
    lines.append(f"  Macro Recall       : {multi_results['macro_recall']:.4f}")
    lines.append(f"  Macro F1           : {multi_results['macro_f1']:.4f}  <-- primary metric")
    lines.append(f"  Weighted Precision : {multi_results['weighted_precision']:.4f}")
    lines.append(f"  Weighted Recall    : {multi_results['weighted_recall']:.4f}")
    lines.append(f"  Weighted F1        : {multi_results['weighted_f1']:.4f}")
    lines.append("")
    lines.append("  Per-class Performance:")
    lines.append(f"    {'Class':<32} {'Prec':>6}  {'Rec':>6}  {'F1':>6}")
    lines.append(f"    {'-'*55}")
    for cls, vals in multi_results["per_class"].items():
        flag = "  <-- low" if vals["f1"] < 0.30 else ""
        lines.append(f"    {cls:<32} {vals['precision']:>6.4f}  "
                     f"{vals['recall']:>6.4f}  {vals['f1']:>6.4f}{flag}")
    lines.append("")
    lines.append("  Classification Report:")
    for line in multi_results["classification_report"].strip().split("\n"):
        lines.append(f"    {line}")
    lines.append("")
    lines.append("  Limitation note:")
    lines.append("    'Random Failures' has very few samples (~18 total, ~4 in test set).")
    lines.append("    Per-class F1 for this class may be low and is considered a known")
    lines.append("    limitation of the dataset, not a model defect.")
    lines.append("")
    lines.append("=" * 65)
    lines.append("  PLOTS GENERATED")
    lines.append("=" * 65)
    lines.append("  results/plots/binary_confusion_matrix.png")
    lines.append("  results/plots/binary_roc_curve.png")
    lines.append("  results/plots/binary_feature_importance.png")
    lines.append("  results/plots/multiclass_confusion_matrix.png")
    lines.append("  results/plots/multiclass_feature_importance.png")
    lines.append("")
    lines.append("=" * 65)

    txt_path = os.path.join(EVAL_DIR, "evaluation_report.txt")
    with open(txt_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"    Saved: {txt_path}")


# ─────────────────────────────────────────────────────────────
# 9. MAIN
# ─────────────────────────────────────────────────────────────
def main():
    print("=" * 65)
    print("  AI PREDICTIVE MAINTENANCE — MODEL EVALUATION")
    print("  IBM / Edunet Problem Statement #39")
    print("=" * 65)

    # Load everything
    (binary_model, X_bin_test, y_bin_test, binary_feature_names,
     multi_model,  X_multi_test, y_multi_test, multi_feature_names,
     class_names) = load_models()

    # Evaluate
    bin_results   = evaluate_binary(binary_model, X_bin_test, y_bin_test)
    multi_results = evaluate_multiclass(multi_model, X_multi_test, y_multi_test,
                                        class_names)

    # Plots
    generate_plots(bin_results, multi_results,
                   binary_model, multi_model,
                   binary_feature_names, multi_feature_names,
                   class_names)

    # Save JSON + text report
    save_results(bin_results, multi_results)

    # ── Terminal summary ──────────────────────────────────────
    print()
    print("=" * 65)
    print("  AI PREDICTIVE MAINTENANCE — MODEL EVALUATION")
    print("=" * 65)
    print()
    print("  BINARY — XGBOOST")
    print(f"    Accuracy  : {bin_results['accuracy']}")
    print(f"    Precision : {bin_results['precision']}")
    print(f"    Recall    : {bin_results['recall']}")
    print(f"    F1        : {bin_results['f1']}")
    print(f"    ROC-AUC   : {bin_results['roc_auc']}")
    print()
    print("  MULTICLASS — RANDOM FOREST")
    print(f"    Accuracy       : {multi_results['accuracy']}")
    print(f"    Macro Precision: {multi_results['macro_precision']}")
    print(f"    Macro Recall   : {multi_results['macro_recall']}")
    print(f"    Macro F1       : {multi_results['macro_f1']}")
    print()
    print("  Evaluation completed successfully.")
    print()
    print("  Plots saved to:")
    print(f"    {PLOTS_DIR}")
    print()
    print("  Reports saved to:")
    print(f"    {EVAL_DIR}")
    print()
    print("=" * 65)


if __name__ == "__main__":
    main()
