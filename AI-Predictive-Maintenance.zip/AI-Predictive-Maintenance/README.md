# AI-Driven Predictive Maintenance System for Industrial Machinery

**IBM / Edunet Foundation Internship — Problem Statement No. 39**
*AI & Machine Learning Course — College Project*

---

## Table of Contents

1. [Project Overview](#1-project-overview)
2. [Problem Statement](#2-problem-statement)
3. [Project Objectives](#3-project-objectives)
4. [Dataset](#4-dataset)
5. [Project Workflow](#5-project-workflow)
6. [Data Preprocessing](#6-data-preprocessing)
7. [Machine Learning Models](#7-machine-learning-models)
8. [Model Performance](#8-model-performance)
9. [Visualizations](#9-visualizations)
10. [Prediction System](#10-prediction-system)
11. [Example Predictions](#11-example-predictions)
12. [Project Structure](#12-project-structure)
13. [How to Run the Project](#13-how-to-run-the-project)
14. [Installation / Requirements](#14-installation--requirements)
15. [Model Limitations](#15-model-limitations)
16. [Future Improvements](#16-future-improvements)
17. [IBM Cloud Integration — Planned / Next Step](#17-ibm-cloud-integration--planned--next-step)
18. [Conclusion](#18-conclusion)

---

## 1. Project Overview

**Predictive Maintenance** is the practice of using data and machine learning models to predict when industrial equipment is likely to fail — *before* the failure actually happens. This allows maintenance teams to act in advance, avoiding costly unplanned downtime and expensive emergency repairs.

This project builds an end-to-end AI-driven predictive maintenance system for industrial machinery. It uses real-world-style sensor data (temperature, speed, torque, tool wear, and machine type) to:

- **Predict whether a machine will fail** (binary classification).
- **Identify the type of failure** when a failure is predicted (multiclass classification).

The system is designed to be practical, explainable, and deployable — making it suitable for real industrial use or integration with IBM Cloud services.

---

## 2. Problem Statement

Industrial machinery operates continuously under varying loads and environmental conditions. Unexpected equipment failures lead to:

- **Production stoppages** and lost revenue
- **Safety hazards** for workers
- **High repair costs** and long maintenance windows

Traditional time-based maintenance schedules are inefficient — they either replace components too early (wasteful) or too late (reactive). **Predictive maintenance** solves this by monitoring sensor data in real time and predicting failures before they occur.

**This project addresses two specific prediction tasks:**

| Task | Description | Target Column |
|------|-------------|---------------|
| **Task 1** | Will the machine fail? | `Target` (0 = No Failure, 1 = Failure) |
| **Task 2** | What type of failure will occur? | `Failure Type` (5 classes) |

---

## 3. Project Objectives

1. **Predict machine failure** — Build a binary classifier to detect whether a machine will fail based on sensor readings.
2. **Identify the failure type** — Build a multiclass classifier to identify the specific type of failure when a failure is predicted.
3. **Compare multiple ML algorithms** — Train and evaluate Logistic Regression, Random Forest, and XGBoost for both tasks.
4. **Evaluate model performance rigorously** — Use accuracy, precision, recall, F1-score, and ROC-AUC as evaluation metrics; handle class imbalance properly.
5. **Generate visualizations** — Produce confusion matrices, ROC curves, and feature importance charts for reporting.
6. **Provide a practical prediction program** — Build a command-line tool that takes machine sensor readings and outputs a failure prediction in real time.
7. **Prepare for IBM Cloud deployment** — Structure the pipeline so that trained models can be deployed on IBM watsonx.ai / IBM Cloud (next step).

---

## 4. Dataset

| Property | Details |
|---|---|
| **File** | `data/predictive_maintenance.csv` |
| **Source** | AI4I 2020 Predictive Maintenance Dataset (UCI / Kaggle) |
| **Total rows** | ~10,000 |
| **Binary target** | `Target` — 0 = No Failure, 1 = Failure |
| **Multiclass target** | `Failure Type` — one of five failure categories |

### Input Features Used by the Models

| Feature | Type | Description |
|---|---|---|
| `Air temperature [K]` | Numerical | Ambient air temperature in Kelvin |
| `Process temperature [K]` | Numerical | Machine process temperature in Kelvin |
| `Rotational speed [rpm]` | Numerical | Spindle rotational speed in RPM |
| `Torque [Nm]` | Numerical | Applied torque in Newton-metres |
| `Tool wear [min]` | Numerical | Cumulative tool usage time in minutes |
| `Type` | Categorical | Machine quality variant: **H** (High), **L** (Low), **M** (Medium) |

> **Encoding:** `Type` is one-hot encoded during preprocessing. Because `drop_first=True` is applied, `H` is used as the reference category and two binary columns are produced: `Type_L` and `Type_M`. The final model input therefore has **7 features**.

### Columns Excluded from Model Inputs

| Column | Reason for Exclusion |
|---|---|
| `UDI` | Row identifier — no predictive value |
| `Product ID` | Row identifier — no predictive value |
| `Failure Type` | Used as the **multiclass target** in Task 2; including it as an input to Task 1 would cause **data leakage** |
| `Target` | Used as the **binary target** in Task 1; including it as an input to Task 2 would cause **data leakage** |

### Failure Type Classes (Task 2)

| Class | Description |
|---|---|
| Heat Dissipation Failure | Overheating due to poor heat dissipation |
| Overstrain Failure | Mechanical strain exceeding limits |
| Power Failure | Electrical power-related failure |
| Random Failures | Unclassified random failure events |
| Tool Wear Failure | Tool degradation beyond usable limits |

---

## 5. Project Workflow

```
Raw Dataset (predictive_maintenance.csv)
        ↓
  Data Inspection / EDA
  (src/data_inspection.py)
        ↓
  Preprocessing & Feature Engineering
  (src/preprocessing.py)
        ↓
  Binary Data Preparation        Multiclass Data Preparation
  (src/prepare_binary.py)        (src/prepare_multiclass.py)
        ↓                                   ↓
  Binary Model Training          Multiclass Model Training
  (src/train_binary.py)          (src/train_multiclass.py)
        ↓                                   ↓
         ──────── Model Evaluation ─────────
                (src/evaluate_models.py)
                        ↓
              Visualizations & Reports
              (results/plots/, results/evaluation/)
                        ↓
              Command-line Prediction
              (src/predict.py)
                        ↓
        IBM Cloud Deployment  ← [PLANNED — NEXT STEP]
```

---

## 6. Data Preprocessing

The preprocessing pipeline is implemented in [`src/preprocessing.py`](src/preprocessing.py) and applied by the preparation scripts.

### Columns Removed
- `UDI` and `Product ID` (identifiers)
- `Failure Type` excluded from Task 1 inputs (data leakage prevention)
- `Target` excluded from Task 2 inputs (data leakage prevention)

### Numerical Feature Scaling
- A custom `NumpyStandardScaler` (mean/std normalisation) is **fitted on the training set only**.
- The same training-set parameters are applied to the test set — no information from the test set is used during fitting.

### Categorical Encoding
- `Type` (H / L / M) is one-hot encoded using a custom `NumpyOneHotEncoder` with `drop_first=True`.
- The encoder is **fitted on the training set only**.
- This produces two binary columns: `Type_L` and `Type_M` (H is the dropped reference category).

### Train / Test Split
- **80% training / 20% test**, stratified on the target column.
- A custom `stratified_split` function ensures the class proportions are preserved in both splits.
- `random_state=42` is used for reproducibility.

### Class Imbalance
- The binary dataset is **severely imbalanced** (~96.6% No Failure vs ~3.4% Failure).
- Addressed using `class_weight="balanced"` in Logistic Regression and Random Forest, and `scale_pos_weight` (majority/minority ratio) in XGBoost.
- **Accuracy alone is not a reliable metric** for this dataset; ROC-AUC and F1-score are the primary evaluation metrics.

### Leakage Prevention
- All scaler and encoder fitting is done **exclusively on training data**.
- The `Failure Type` column perfectly encodes the binary `Target` column and is therefore never used as an input feature.

---

## 7. Machine Learning Models

### Task 1 — Binary Failure Prediction

Three models were trained and compared:

| Model | Key Configuration |
|---|---|
| Logistic Regression | `class_weight="balanced"`, `max_iter=1000` |
| Random Forest | `n_estimators=300`, `class_weight="balanced"` |
| **XGBoost** ⭐ | `n_estimators=300`, `scale_pos_weight=majority/minority ratio` |

> **Selected model: XGBoost** — best ROC-AUC and Failure-class F1 on the test set.

### Task 2 — Multiclass Failure Type Classification

Only rows where a failure occurred (`Failure Type != "No Failure"`) are used — this is a **5-class classification** problem.

| Model | Key Configuration |
|---|---|
| Logistic Regression | `class_weight="balanced"`, `max_iter=2000` |
| **Random Forest** ⭐ | `n_estimators=300`, `class_weight="balanced"` |
| XGBoost | `n_estimators=300`, `sample_weight` from class frequencies |

> **Selected model: Random Forest** — best Macro F1 on the test set.

---

## 8. Model Performance

> All metrics are calculated from the held-out **test set only**. No model was retrained for evaluation.
> Source: [`results/evaluation/model_evaluation.json`](results/evaluation/model_evaluation.json)

### Task 1 — Binary Failure Prediction (XGBoost)

| Metric | Value |
|---|---|
| **Accuracy** | 98.35% |
| **Precision** (Failure class) | 0.7692 |
| **Recall** (Failure class) | 0.7353 |
| **F1-score** (Failure class) | 0.7519 |
| **ROC-AUC** | **0.9641** |

**Confusion Matrix (test set — 2,000 samples):**

|  | Predicted: No Failure | Predicted: Failure |
|---|---|---|
| **Actual: No Failure** | TN = 1917 | FP = 15 |
| **Actual: Failure** | FN = 18 | TP = 50 |

> The high ROC-AUC (0.9641) indicates excellent discriminative ability. The F1-score of 0.75 for the minority Failure class is strong given the 28:1 class imbalance in the dataset.

---

### Task 2 — Failure Type Classification (Random Forest)

| Metric | Value |
|---|---|
| **Accuracy** | 88.57% |
| **Macro Precision** | 0.8990 |
| **Macro Recall** | 0.8641 |
| **Macro F1** | **0.8757** |
| **Weighted Precision** | 0.8911 |
| **Weighted Recall** | 0.8857 |
| **Weighted F1** | 0.8847 |

**Per-class Performance (test set — 70 failure samples):**

| Failure Type | Precision | Recall | F1-score | Support |
|---|---|---|---|---|
| Heat Dissipation Failure | 0.875 | 0.955 | **0.913** | 22 |
| Overstrain Failure | 0.882 | 0.938 | **0.909** | 16 |
| Power Failure | 0.938 | 0.789 | **0.857** | 19 |
| Random Failures | 1.000 | 0.750 | **0.857** | 4 |
| Tool Wear Failure | 0.800 | 0.889 | **0.842** | 9 |

---

## 9. Visualizations

All plots are saved to [`results/plots/`](results/plots/).

| Plot File | Description |
|---|---|
| [`binary_confusion_matrix.png`](results/plots/binary_confusion_matrix.png) | 2×2 matrix showing TN, FP, FN, TP for the binary XGBoost model |
| [`binary_roc_curve.png`](results/plots/binary_roc_curve.png) | ROC curve with AUC score annotated in the legend |
| [`binary_feature_importance.png`](results/plots/binary_feature_importance.png) | Horizontal bar chart of XGBoost feature importances (7 features, sorted) |
| [`multiclass_confusion_matrix.png`](results/plots/multiclass_confusion_matrix.png) | 5×5 matrix with actual failure-type class names on both axes |
| [`multiclass_feature_importance.png`](results/plots/multiclass_feature_importance.png) | Horizontal bar chart of Random Forest feature importances (7 features, sorted) |

> All plots are generated by [`src/evaluate_models.py`](src/evaluate_models.py) using **matplotlib** (no seaborn dependency).

---

## 10. Prediction System

[`src/predict.py`](src/predict.py) is a beginner-friendly command-line prediction tool that uses the saved models and preprocessing artifacts to make real-time predictions without retraining anything.

### Prediction Flow

```
  User enters 6 machine readings
  (Air temp, Process temp, Speed, Torque, Tool wear, Type)
          ↓
  Input validation
  (numeric checks, Type must be H / L / M)
          ↓
  Preprocessing
  (scale with saved means/stds, one-hot encode Type)
          ↓
  Binary XGBoost model
          ↓
    ┌─────────────────────────────┐
    │                             │
  NO FAILURE                  FAILURE
  (show probability,          (run multiclass model)
   show "operating normally")         ↓
                          Random Forest model
                                   ↓
                          Decode with label encoder
                                   ↓
                          Display failure type name
                          + "Maintenance recommended"
```

> **The multiclass model is only called when the binary model predicts a failure.**
> If the machine is predicted to be healthy, the pipeline stops at the binary step for efficiency.

---

## 11. Example Predictions

### Example 1 — Healthy Machine

```
Input:
  Air temperature [K]     : 298
  Process temperature [K] : 308
  Rotational speed [rpm]  : 1500
  Torque [Nm]             : 40
  Tool wear [min]         : 10
  Machine Type (H/L/M)    : M

Output:
  --------------------------------
  PREDICTIVE MAINTENANCE RESULT
  --------------------------------
  Failure            : NO
  Failure Probability: 0.00%
  Status             : Machine operating normally
  --------------------------------
```

### Example 2 — Machine Under Stress (Failure Detected)

```
Input:
  Air temperature [K]     : 305
  Process temperature [K] : 315
  Rotational speed [rpm]  : 1200
  Torque [Nm]             : 68
  Tool wear [min]         : 220
  Machine Type (H/L/M)    : L

Output:
  --------------------------------
  PREDICTIVE MAINTENANCE RESULT
  --------------------------------
  Failure            : YES
  Failure Probability: 100.00%
  Failure Type       : Overstrain Failure
  Status             : Maintenance recommended
  --------------------------------
```

---

## 12. Project Structure

```
AI-Predictive-Maintenance/
│
├── data/
│   ├── predictive_maintenance.csv      # Raw dataset
│   ├── binary_X_train.npy              # Preprocessed binary training features
│   ├── binary_X_test.npy               # Preprocessed binary test features
│   ├── binary_y_train.npy              # Binary training labels
│   ├── binary_y_test.npy               # Binary test labels
│   ├── multi_X_train.npy               # Preprocessed multiclass training features
│   ├── multi_X_test.npy                # Preprocessed multiclass test features
│   ├── multi_y_train.npy               # Multiclass training labels
│   └── multi_y_test.npy                # Multiclass test labels
│
├── src/
│   ├── data_inspection.py              # Step 1 — EDA & quality audit
│   ├── preprocessing.py               # Step 2 — Shared preprocessing classes
│   ├── prepare_binary.py              # Step 2a — Binary data preparation
│   ├── prepare_multiclass.py          # Step 2b — Multiclass data preparation
│   ├── train_binary.py                # Step 3 — Binary model training
│   ├── train_multiclass.py            # Step 4 — Multiclass model training
│   ├── evaluate_models.py             # Step 5 — Model evaluation & visualisation
│   └── predict.py                     # Step 6 — Command-line prediction tool
│
├── models/
│   ├── binary_xgboost.joblib           # ⭐ Best binary model (XGBoost)
│   ├── binary_random_forest.joblib     # Binary Random Forest
│   ├── binary_logistic_regression.joblib
│   ├── binary_scaler_means.npy         # Scaler parameters (binary)
│   ├── binary_scaler_stds.npy
│   ├── binary_ohe_ohe.json             # One-hot encoder config (binary)
│   ├── binary_feature_names.json       # Feature names used by binary models
│   ├── binary_feature_importance.csv
│   ├── binary_results.json
│   ├── multi_random_forest.joblib      # ⭐ Best multiclass model (Random Forest)
│   ├── multi_xgboost.joblib
│   ├── multi_logistic_regression.joblib
│   ├── multi_scaler_means.npy          # Scaler parameters (multiclass)
│   ├── multi_scaler_stds.npy
│   ├── multi_ohe_ohe.json              # One-hot encoder config (multiclass)
│   ├── multi_label_encoder_le.json     # Failure type label encoder
│   ├── multi_feature_names.json        # Feature names used by multiclass models
│   ├── multi_feature_importance.csv
│   └── multi_results.json
│
├── results/
│   ├── evaluation/
│   │   ├── model_evaluation.json       # Machine-readable metrics
│   │   └── evaluation_report.txt       # Human-readable full report
│   └── plots/
│       ├── binary_confusion_matrix.png
│       ├── binary_roc_curve.png
│       ├── binary_feature_importance.png
│       ├── multiclass_confusion_matrix.png
│       └── multiclass_feature_importance.png
│
├── requirements.txt
└── README.md
```

---

## 13. How to Run the Project

> **Prerequisites:** Python 3.8+ with the packages listed in [requirements.txt](requirements.txt) installed.

Run each step from the **project root directory** (`AI-Predictive-Maintenance/`).

### Step 1 — Data Inspection / EDA
```bash
python src/data_inspection.py
```
Prints dataset shape, column types, missing values, class distributions, and a data leakage check. Does not train any models.

### Step 2 — Data Preparation

```bash
# Binary classification data prep
python src/prepare_binary.py

# Multiclass classification data prep
python src/prepare_multiclass.py
```
Applies scaling and one-hot encoding (fit on training data only), stratified 80/20 split, and saves preprocessed arrays to `data/`.

### Step 3 — Model Training

```bash
# Train binary models (Logistic Regression, Random Forest, XGBoost)
python src/train_binary.py

# Train multiclass models (Logistic Regression, Random Forest, XGBoost)
python src/train_multiclass.py
```
Trains three models per task, evaluates on the test set, selects the best model, and saves all models and results to `models/`.

### Step 4 — Model Evaluation & Visualisation
```bash
python src/evaluate_models.py
```
Loads the best saved models, recalculates all metrics on the test set, generates all five plots, and saves `results/evaluation/model_evaluation.json` and `results/evaluation/evaluation_report.txt`.

### Step 5 — Run a Prediction
```bash
python src/predict.py
```
Launches the interactive command-line prediction tool. Enter machine sensor readings when prompted and receive an instant failure prediction.

---

## 14. Installation / Requirements

Install all dependencies with:

```bash
pip install -r requirements.txt
```

**Required libraries** (from [`requirements.txt`](requirements.txt)):

| Library | Version | Purpose |
|---|---|---|
| `pandas` | ≥ 2.0.0 | Data loading and manipulation |
| `numpy` | ≥ 1.24.0 | Numerical arrays and preprocessing |
| `scikit-learn` | ≥ 1.3.0 | ML models, metrics, and utilities |
| `imbalanced-learn` | ≥ 0.11.0 | SMOTE (available as backup strategy) |
| `matplotlib` | ≥ 3.7.0 | Visualisation and plots |
| `xgboost` | ≥ 2.0.0 | XGBoost classifier |
| `joblib` | ≥ 1.3.0 | Model serialisation / loading |

---

## 15. Model Limitations

### Class Imbalance (Binary Task)
The dataset contains approximately **96.6% No Failure** vs **3.4% Failure** samples. This severe imbalance means:
- Accuracy is not a meaningful standalone metric (a trivial "always predict No Failure" classifier would score ~96.6%).
- **ROC-AUC (0.9641)** and **F1-score (0.7519)** for the Failure class are the reliable indicators of model quality.
- Class-weight balancing was applied, but some false negatives remain (18 missed failures in the test set).

### Small Sample Size for Random Failures (Multiclass Task)
The **Random Failures** class has only **~18 total samples** in the dataset, resulting in just **4 test samples**. While the Random Forest achieved an F1 of 0.857 on this class, this result is not statistically reliable due to the tiny test support. This is a known limitation of the dataset, not a model defect.

### No Real-Time Sensor Integration
The current system works with manually entered or batch sensor readings. It does not yet integrate with real industrial IoT sensors or streaming data pipelines.

### Dataset Scope
The model was trained on the AI4I 2020 synthetic predictive maintenance dataset. Real-world performance on different machinery or operating environments may differ and would require retraining on domain-specific data.

---

## 16. Future Improvements

| Improvement | Priority | Notes |
|---|---|---|
| **Collect more failure data** | High | Especially for rare classes like Random Failures |
| **SMOTE oversampling** | Medium | Already available via `imbalanced-learn`; apply on training set only |
| **Hyperparameter tuning** | Medium | Grid search / Bayesian optimisation for XGBoost and Random Forest |
| **Additional sensor features** | Medium | Vibration, acoustic emissions, current draw, etc. |
| **Real-time IoT integration** | High | Connect to live PLC/SCADA sensor streams |
| **Model monitoring & drift detection** | High | Track prediction distribution over time in production |
| **IBM Cloud deployment** | High | Deploy models to IBM watsonx.ai for scalable cloud inference (see below) |

---

## 17. IBM Cloud Integration — Planned / Next Step

> ⚠️ **IBM Cloud deployment has NOT been completed yet.**
> This section describes the intended next step after the local ML pipeline is finalised.

The trained models (`binary_xgboost.joblib` and `multi_random_forest.joblib`) are intended to be deployed to **IBM watsonx.ai** / **IBM Cloud** to enable:

- **Scalable inference** — serve predictions via a REST API without requiring a local Python environment.
- **Model management** — version control, A/B testing, and performance monitoring through the IBM Watson Machine Learning service.
- **Integration with industrial systems** — connect to plant-floor systems, dashboards, or IoT platforms via the IBM Cloud API.

**Planned integration steps (future work):**

1. Register a free IBM Cloud account and provision a Watson Machine Learning instance.
2. Export the trained models to the ONNX format or upload the `.joblib` files directly to Watson ML.
3. Create a deployment space and deploy the models as online scoring endpoints.
4. Call the scoring endpoints from the prediction script or a monitoring dashboard.
5. Set up model monitoring using IBM OpenScale / Watson OpenScale.

> No IBM Cloud endpoint, deployment ID, API key, or scoring URL has been created yet. All metrics and predictions in this README are from **local evaluation only**.

---

## 18. Conclusion

This project successfully delivers a complete, end-to-end AI-driven predictive maintenance system for industrial machinery:

- **Data was inspected, cleaned, and preprocessed** with careful attention to class imbalance and leakage prevention.
- **Six machine learning models** were trained across two tasks (binary and multiclass), evaluated with multiple metrics, and the best-performing models were selected.
- **Binary XGBoost** achieved a **ROC-AUC of 0.9641** and a **Failure-class F1 of 0.7519** on the held-out test set — excellent performance given the 28:1 class imbalance.
- **Multiclass Random Forest** achieved a **Macro F1 of 0.8757** across all five failure types, correctly identifying the dominant failure classes with high precision and recall.
- **Five visualizations** (confusion matrices, ROC curve, feature importance charts) were generated and saved for reporting and presentation.
- **A command-line prediction tool** allows any user to enter live machine readings and receive an instant failure prediction and failure type diagnosis.
- The project is structured for **IBM Cloud deployment** as the next step, with all model artefacts and preprocessing parameters saved in a portable format.

---

## Author / Project Information

| Field | Details |
|---|---|
| **Project** | AI-Driven Predictive Maintenance System for Industrial Machinery |
| **Programme** | IBM / Edunet Foundation Internship |
| **Problem Statement** | No. 39 — Predictive Maintenance of Industrial Machinery |
| **Course** | AI & Machine Learning |
| **Dataset** | AI4I 2020 Predictive Maintenance Dataset (UCI / Kaggle) |
